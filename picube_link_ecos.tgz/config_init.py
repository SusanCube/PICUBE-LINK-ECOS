
PCIE_DRIV_FILE = "./pcie.so"

#######################################################################################
#HUBS_ECOS_FILE = "backup/tpuc_ecos_2026031114.img"
HUBS_ECOS_FILE = "database/tpuc_ecos_2026031114.img"
#######################################################################################
#CUBE_BITS_FILE = "backup/fpga_slx9_tops_2026031603.bit"
CUBE_BITS_FILE = "database/fpga_slx9_tops_2026031603.bit"
#CUBE_BITS_FILE = "database/fpga_slx9_tops_2026050404.bit"
CUBE_BITS_FILE = "database/fpga_slx9_tops_2026050406.bit"
CUBE_BITS_FILE = "database/fpga_slx9_tops_2026050503.bit"
CUBE_BITS_FILE = "database/fpga_slx9_tops_2026050610.bit"
#######################################################################################
#CUBE_ECOS_FILE 	= f"backup/ddrV1_dfif256_AutoTDC_600M2GBxRnk2_20260127.img"#FORSEE
#CUBE_ECOS_FILE 	= f"backup/ddrV1_dfif256_AutoTDC_600M4GBxRnk1_20260127.img"#NANYA
CUBE_ECOS_FILE 	= f"database/ddrV1_dfif256_AutoTDC_600M2GBxRnk2_20260127.img"#NANYA
#CUBE_ECOS_FILE 	= f"database/ddrV1_dfif256_AutoTDC_600M4GBxRnk1_20260127.img"#FORSEE
#######################################################################################
#GNPU_ECOS_FILE	= "../icube/agile_Theta_GpVh2_QWEN3_4B.img"
GNPU_ECOS_FILE	= f"database/agile_Theta_GpVh2_QWEN3_4B.img"
#######################################################################################
WGHT_PATH       = "../../../weights/Qwen3/Qwen3-4B/Qwen3-4B-Recombination-chip_64-20260120-pick_rows32_columns128"
WGHT_POSI       = "../../../weights/Qwen3/position.json"
