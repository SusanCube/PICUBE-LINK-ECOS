import os
import datetime
from ctypes import *
from config import *

pcie = CDLL("./pcie.so")
##################################################################################################
class PCIe_Base(object):

    def __init__(self, cid):
        self.Card_ID = cid
        self.Time = datetime.datetime.now()
        self.ScanTime = datetime.datetime.now()

        self.LogBakDir = f"LogCard"
        self.LogName = f"Card{cid}_Log.log"
        self.ExtName = f"Card{cid}_Ext.log"

        if not os.path.exists(f"{self.LogBakDir}"):
            os.makedirs(f"{self.LogBakDir}")

        if len(sys.argv) > 1 and sys.argv[1] == "agile" and os.path.exists(self.LogName):
            i = 0
            while 1:
                if os.path.exists(f"{self.LogBakDir}/{self.LogName}.{i}"):
                    i = i+1
                else:
                    break
            os.rename(f"{self.LogName}", f"{self.LogBakDir}/{self.LogName}.{i}")
        elif len(sys.argv) > 1 and sys.argv[1] == "infer" and os.path.exists(self.ExtName):
            i = 0
            while 1:
                if os.path.exists(f"{self.LogBakDir}/{self.ExtName}.{i}"):
                    i = i+1
                else:
                    break
            os.rename(f"{self.ExtName}", f"{self.LogBakDir}/{self.ExtName}.{i}")


        if len(sys.argv) > 1 and sys.argv[1] == "agile":
            self.Log = open(f"{self.LogName}", "w")
        else:
            self.Log = open(f"{self.ExtName}", "w")
##################################################################################################
    def us_sleep(self, n):
        self.PCIe_WriteCtrl(0x39, [n*3])
        data = [1]
        while data[0] != 0:
            data = self.PCIe_ReadCtrl(0x39)
##################################################################################################
    def ms_sleep(self, n):
        self.us_sleep(1000*n)
##################################################################################################
    def pcie_reg_write(self, addr, data, data_len):
        INPUT = c_uint32 * data_len
        c_data = INPUT()
        for i in range(data_len):
            c_data[i] = data[i]
        pcie.pcie_reg_write(self.Card_ID, addr, c_data, data_len)
##################################################################################################
    def pcie_reg_read(self, addr, data, data_len):
        pcie.pcie_reg_read(self.Card_ID, addr, data, data_len)
##################################################################################################
    def PCIe_WriteCtrl(self, addr, data):
        addr = addr*4
        data_len = len(data)
        self.pcie_reg_write(addr, data, data_len)
##################################################################################################
    def PCIe_ReadCtrl(self, addr=0, data_len=1):
        addr = addr*4
        INPUT = c_uint32 * data_len
        data = INPUT()
        
        self.pcie_reg_read(addr, data, data_len)
        return data
##################################################################################################
    def pcie_cfig_cmnd(self, port_enab, tpgs, tpes, edge, madr=0, sadr=0,  rows_numb=0, cols_numb=0, rows_pack=0, pack_page=0, dlnk_pack=0, dlnk_mult=0, aux0=0, aux1=0, aux2=0, aux3=0):
        cmds = [             port_enab, tpgs, tpes, edge, madr,    sadr,    rows_numb,  cols_numb,   rows_pack,   pack_page,   dlnk_pack,   dlnk_mult,   aux0,   aux1,   aux2,   aux3]
        self.PCIe_WriteCtrl(DEST_PORT_ENAB, cmds)
##################################################################################################
    def PCIe_ReadCtrl_Util(self, PCIe_REGS, PCIe_Val,VALS_Mask=0xffffffff):#, PCIe_Mask=0xffffffff):
        
        while 1:
            STAT = self.PCIe_ReadCtrl(PCIe_REGS, 1)
            rdata = STAT[0]&VALS_Mask
            if(rdata == PCIe_Val):
                 return
            else:
                 self.us_sleep(1)   
##################################################################################################
#    def pcie_cfig_nnex(self, aux1=0, aux2=0):
#        self.PCIe_WriteCtrl(DEST_PORT_ENAB + 13, [aux1, aux2, 0x15000053])
###################################################################################################
#    def pcie_cfig_nnex_cfig(self):
#        self.PCIe_WriteCtrl(DEST_PORT_ENAB, [APAE, 0, 0, 2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x15000053])
##################################################################################################
    def root_cold_rstn_hubs(self,rt,bt):
        print(f"Card Cold Reset {rt} Seconds")
        self.PCIe_WriteCtrl(TPGM_GSET_CTRL, [0x0])
        for i in range(rt):
            self.ms_sleep(1000)
            print("-",end="")
        print(f"\nCard Cold Reset Done,Boot up {bt} Seconds")
        self.PCIe_WriteCtrl(TPGM_GSET_CTRL, [0x1])
        for i in range(bt):
            self.ms_sleep(1000)
            print("~",end="")
        status=self.PCIe_ReadCtrl(TPGM_GSET_CTRL, 0xf)
        print(f"\nAgile Card ready::STATUS{status[0]:08X}")
##################################################################################################
    def pcie_issu_cmnd(self, cmnd):
        self.PCIe_WriteCtrl(TPGM_CMND_CTRL, [cmnd])
        if cmnd == LLMB_ICFG_CMND:   ## 0x11
            self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_ICFG_CMND_rdy)
        elif cmnd == LLMB_OCFG_CMND: ## 0x12
            self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_OCFG_CMND_rdy)
        elif cmnd == LLMB_NNEX_CMND: ## 0x13
            self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_NNEX_CMND_rdy)
        elif cmnd == LLMB_IVCT_CMND: ## 0x21
            self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_IVCT_CMND_rdy)
        elif cmnd == LLMB_OVCT_CMND: ## 0x22
            self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_OVCT_CMND_rdy)
        elif cmnd == LLMB_IMTX_CMND: ## 0x23
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_IMTX_CMND_rdy)
        elif cmnd == LLMB_OMTX_CMND: ## 0x24
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_OMTX_CMND_rdy)
        elif cmnd == LLMB_RIVT_CMND: ## 0x31
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_RIVT_CMND_rdy)
        elif cmnd == LLMB_ROVT_CMND: ## 0x32
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_ROVT_CMND_rdy)
        elif cmnd == LLMB_RIMT_CMND: ## 0x33
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_RIMT_CMND_rdy)
        elif cmnd == LLMB_ROMT_CMND: ## 0x34
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_ROMT_CMND_rdy)
        elif cmnd == LLMB_RISV_CMND: ## 0x41
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_RISV_CMND_rdy)
        elif cmnd == LLMB_ROSV_CMND: ## 0x42
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_ROSV_CMND_rdy)
        elif cmnd == LLMB_RISM_CMND: ## 0x43 ## 0x41
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_RISM_CMND_rdy, LLMB_RISM_CMND_rdy)
        elif cmnd == LLMB_ROSM_CMND: ## 0x44 ## 0x42
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_ROSM_CMND_rdy)
        elif cmnd == LLMB_ASET_CMND: ## 0x51
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_ASET_CMND_rdy)
        elif cmnd == LLMB_DNLD_CMND: ## 0x52
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_DNLD_CMND_rdy)
        elif cmnd == LLMB_BOOT_CMND: ## 0x53
                self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_BOOT_CMND_rdy)
        elif cmnd == LLMB_TRIM_CMND: ## 0x88
            self.PCIe_ReadCtrl_Util(TPGM_CMND_CTRL, LLMB_TRIM_CMND_rdy)
##################################################################################################
    def pcie_down_load(self, code, dtar=0,time=0):
        leng = len(code)
        bls = [hex(it) for it in code]
        i = 0
        if dtar == 0:
            print(f"\t\t\t\t********Download HUBS CodeRam::{leng} PACKAGES")
        else:
            print(f"\t\t\t\t********Download EDGE BitFile::{leng} PACKAGES")
        while (i<leng):
            print(".",end="",flush=True)
            self.PCIe_WriteCtrl(META_ROWS_NUMB, code[i:i+8])
            self.pcie_issu_cmnd(LLMB_DNLD_CMND)
            i = i + 8
            if(time):
                self.ms_sleep(time)
        if dtar == 0:    
            print(f"\n\t\t\t\t********Download HUBS CodeRam  Done!")
        else:
            print(f"\n\t\t\t\t********Download EDGE BitFile  Done!")
##################################################################################################
#base on pcie.pcie_dma_write
    ##################################################################################################
    def pcie_dma_write(self, filename, src_offset, leng, max_splt_size=0x3fffffff):
        pcie.pcie_dma_write(self.Card_ID, filename, src_offset, leng, max_splt_size)
    ##################################################################################################
    def PCIe_WriteData(self, fname, src_offset=0, leng=0, max_splt_size=0x3fffffff):
        filename = bytes(fname, encoding="utf-8")
        self.pcie_dma_write(filename, src_offset, leng, max_splt_size)
    ##################################################################################################
    ##  addr 32byte address
    def pcie_wdma_ddrs(self, fname, addr, rows, cols, src_offset_spot=0, max_splt_size=0x3fffffff):
        rows = int(rows)
        cols = int(cols)
        if cols == 0:
            return
        self.PCIe_WriteCtrl(PCIE_XDMA_DDRS_ADDR, [addr])
        #self.PCIe_WriteCtrl(PCIE_XDMA_ROWS_NUMB, [rows])
        self.PCIe_WriteCtrl(PCIE_XDMA_ROWS_NUMB, [1])
        self.PCIe_WriteCtrl(PCIE_XDMA_COLS_NUMB, [rows*cols])
        self.PCIe_WriteCtrl(PCIE_XDMA_CMND, [PCIE_XDMA_CMND_wdma])
        ## Axi-Stream, No addr signal
        if 1 and max_splt_size == 0x3fffffff:
            max_splt_size = 0x00100000
        self.PCIe_WriteData(fname, src_offset_spot*2, rows*cols*2, max_splt_size)
        #self.PCIe_WriteData(fname, src_offset_spot*2, 0)
        self.PCIe_ReadCtrl_Util(PCIE_XDMA_CMND, PCIE_XDMA_CMND_wdma_rdy, PCIE_XDMA_CMND_wdma_rdy)
##################################################################################################
#base on pcie.pcie_dma_read
    ##################################################################################################
    def pcie_dma_read(self, filename, leng, RdStep):
        pcie.pcie_dma_read(self.Card_ID, filename, leng, RdStep)
    ##################################################################################################
    def PCIe_ReadData(self, fname, leng=0, RdStep=0x3fffffff):
        filename = bytes(fname, encoding="utf-8")
        self.pcie_dma_read(filename, leng, RdStep)
    ##################################################################################################
    ##  addr 32byte address
    def pcie_rdma_ddrs(self, fname, addr, rows, cols, RdStep=0x3fffffff):
        rows = int(rows)
        cols = int(cols)
        if cols == 0:
            return
        #input("trig pcie")
        self.PCIe_WriteCtrl(PCIE_XDMA_DDRS_ADDR, [addr])
        #self.PCIe_WriteCtrl(PCIE_XDMA_ROWS_NUMB, [rows])
        self.PCIe_WriteCtrl(PCIE_XDMA_COLS_NUMB, [rows*cols])
        self.PCIe_WriteCtrl(PCIE_XDMA_CMND, [PCIE_XDMA_CMND_rdma])
        ## Axi-Stream, No addr signal
        if 0 and RdStep == 0x3fffffff:
            RdStep = 0x00010000  ## this cause error, but why?
        self.PCIe_ReadData(fname, rows*cols*2, RdStep)
        self.PCIe_ReadCtrl_Util(PCIE_XDMA_CMND, PCIE_XDMA_CMND_rdma_rdy, PCIE_XDMA_CMND_rdma_rdy)
##################################################################################################
    def pcie_2805_load(self, code):
        leng = len(code)
        bls = [hex(it) for it in code]
        i = 0
        print(f"\t\t\t\t\t\t********PCIE DownLoad S2805 CodeRAM {leng} PACKAGES")

        while (i<leng-8):
            #self.DEBUG4(f"writting {i} of {leng} {bls[i:i+8]}")
            print(".",end="",flush=True)
            self.PCIe_WriteCtrl(EDGE_DEST_MARK, code[i+0:i+1])
            self.PCIe_WriteCtrl(SLAV_DDRS_BASE, code[i+1:i+2])
            self.PCIe_WriteCtrl(META_ROWS_NUMB, code[i+2:i+4])
            self.PCIe_WriteCtrl(EDGE_AUXI_WRD0, code[i+4:i+8])
            self.pcie_issu_cmnd(LLMB_DNLD_CMND)
            i = i + 8
        #self.DEBUG4(f"writting {i} of {leng} {bls[i:i+8]}")
        print(".",end="",flush=True)
        self.PCIe_WriteCtrl(EDGE_DEST_MARK, code[i+0:i+2])
        self.PCIe_WriteCtrl(DLNK_BULK_PACK, code[i+2:i+4])
        self.PCIe_WriteCtrl(EDGE_AUXI_WRD0, code[i+4:i+8])
        self.pcie_issu_cmnd(LLMB_DNLD_CMND)
##################################################################################################
# base on   pcie.pcie_buf_read          
    ##################################################################################################
    def pcie_dma_buffer_read(self, data, leng, RdStep):
        INPUT = c_uint8 * leng
        c_data = INPUT()    
        pcie.pcie_buf_read(self.Card_ID, c_data, leng, RdStep)
        for i in range(leng):
            data[i] = c_data[i]
    ##################################################################################################
    def PCIe_ReadDataBuffer(self, data, leng=0, RdStep=0x3fffffff):
        self.pcie_dma_buffer_read(data, leng, RdStep)
##################################################################################################
# base on   pcie.pcie_buf_write          
    ##################################################################################################
    def pcie_dma_buffer_write(self, data, src_offset, leng, max_splt_size=0x3fffffff):
        total_len = src_offset+leng      
        INPUT = c_uint8 * total_len
        c_data = INPUT()
        for i in range(total_len):
            c_data[i] = data[i]
        
        pcie.pcie_buf_write(self.Card_ID, c_data, src_offset, leng, max_splt_size)
    ##################################################################################################
    def PCIe_WriteDataBuffer(self, data, src_offset=0, leng=0, max_splt_size=0x3fffffff):
        self.pcie_dma_buffer_write(data, src_offset, leng, max_splt_size)
##################################################################################################
#final
##################################################################################################
    ##  addr 32byte address
    def pcie_wdma_root_ddrs(self, data, addr, rows, cols):
        rows = int(rows)
        cols = int(cols)
        if cols == 0:
            print(" HOST WDMA ROOT DDRS' FetalERR::Data length be ZERO!!!")
            return
        self.PCIe_WriteCtrl(PCIE_XDMA_DDRS_ADDR, [addr])
        self.PCIe_WriteCtrl(PCIE_XDMA_COLS_NUMB, [rows*cols])
        self.PCIe_WriteCtrl(PCIE_XDMA_CMND, [PCIE_XDMA_CMND_wdma])
        #max_splt_size = 0x10000000
        self.PCIe_WriteDataBuffer(data, 0, rows*cols*2, 0x3fffffff)#max_splt_size)
        self.PCIe_ReadCtrl_Util(PCIE_XDMA_CMND, PCIE_XDMA_CMND_wdma_rdy, PCIE_XDMA_CMND_wdma_rdy)
###################################################################################################
    ##  addr 32byte address
    def pcie_rdma_root_ddrs(self, data, addr, rows, cols, RdStep=0x3fffffff):
         rows = int(rows)
         cols = int(cols)
         if cols == 0:
             print(" HOST RDMA ROOT DDRS' FetalERR::Data length be ZERO!!!")
             return
         self.PCIe_WriteCtrl(PCIE_XDMA_DDRS_ADDR, [addr])
         self.PCIe_WriteCtrl(PCIE_XDMA_COLS_NUMB, [rows*cols])
         self.PCIe_WriteCtrl(PCIE_XDMA_CMND, [PCIE_XDMA_CMND_rdma])
         #RdStep = 0x3fffffff  ## this cause error, but why?
         self.PCIe_ReadDataBuffer(data, rows*cols*2, 0x3fffffff)#RdStep)
         self.PCIe_ReadCtrl_Util(PCIE_XDMA_CMND, PCIE_XDMA_CMND_rdma_rdy, PCIE_XDMA_CMND_rdma_rdy)
 ###################################################################################################
    ##################################################################################################
    ##  addr 32byte address
    #def pcie_wdma_ddrs_buffer(self, data, addr, rows, cols, src_offset_spot=0, max_splt_size=0x3fffffff):
    #    rows = int(rows)
    #    cols = int(cols)
    #    if cols == 0:
    #        print("PCIE WDMA FetalERR::Data length be ZERO!!!")
    #    
    #    self.PCIe_WriteCtrl(PCIE_XDMA_DDRS_ADDR, [addr])
    #    self.PCIe_WriteCtrl(PCIE_XDMA_ROWS_NUMB, [1])
    #    self.PCIe_WriteCtrl(PCIE_XDMA_COLS_NUMB, [rows*cols])
    #    self.PCIe_WriteCtrl(PCIE_XDMA_CMND, [PCIE_XDMA_CMND_wdma])
    #    ## Axi-Stream, No addr signal
    #    if 1 and max_splt_size == 0x3fffffff:
    #        max_splt_size = 0x00100000
    #    self.PCIe_WriteDataBuffer(data, src_offset_spot*2, rows*cols*2, max_splt_size)
    #    #self.PCIe_WriteData(fname, src_offset_spot*2, 0)
    #    self.PCIe_ReadCtrl_Util(PCIE_XDMA_CMND, PCIE_XDMA_CMND_wdma_rdy, PCIE_XDMA_CMND_wdma_rdy)
    ##################################################################################################
    ##  addr 32byte address
    #def pcie_rdma_ddrs_buffer(self, data, addr, rows, cols, RdStep=0x3fffffff):
    #    rows = int(rows)
    #    cols = int(cols)
    #    if cols == 0:
    #        return
    #    
    #    self.PCIe_WriteCtrl(PCIE_XDMA_DDRS_ADDR, [addr])
    #    self.PCIe_WriteCtrl(PCIE_XDMA_COLS_NUMB, [rows*cols])
    #    self.PCIe_WriteCtrl(PCIE_XDMA_CMND, [PCIE_XDMA_CMND_rdma])
    #    ## Axi-Stream, No addr signal
    #    if 0 and RdStep == 0x3fffffff:
    #        RdStep = 0x00010000  ## this cause error, but why?
    #    self.PCIe_ReadDataBuffer(data, rows*cols*2, RdStep)
    #    self.PCIe_ReadCtrl_Util(PCIE_XDMA_CMND, PCIE_XDMA_CMND_rdma_rdy, PCIE_XDMA_CMND_rdma_rdy)
