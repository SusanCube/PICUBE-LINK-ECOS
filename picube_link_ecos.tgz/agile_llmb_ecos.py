import os
import sys
import time

from config import *
from config_ecos import *
from pcie_core_func import *
from pcie_core_func import *

from base_core_util import *

from conv_demo_list import *
from llmb_infer_ecos import *
from datetime import datetime as dt
from transformers import AutoTokenizer

def Agile_Elaberate():
    for i in range(8):
        fileName = f"/dev/chiprise{i}_user"
        if os.path.exists(fileName):
            AgileCard.append(Agile_LLMB_ECOS(i))
        else:
            break
    
    return AgileCard

class Agile_LLMB_ECOS(LLMB_INFER_ECOS,PCIe_CORE):
    def __init__(self, cid):
        PCIe_CORE.__init__(self, cid)

    def Agile_LLMB_Infer(self):
    
        now = dt.now()

        print(now.strftime("\n\t\t%Y年%m月%d日 %H时%M分%S秒\n\n"))

        for Test_Case in range(10):

            loop_run_time = time.time()
            for list_item in range(21):

                task_run_time = time.time()

                print(f"\n\t\t---- ----测试循环{Test_Case}----会话任务{list_item}开始---- ----")

                conv_item  = gets_conv_item(list_item)
                print(f"{conv_item}")

                task_posi =    0   
                task_vect ,task_size ,task_tkid = self.llmb_str2_tokn_vect(conv_item)  

                self.llmb_infer_solo_task(Test_Case,task_vect,task_posi,task_size,INFER_MLPS_LOOP)
                #14self.Refresh_LVDS_intf()
                task_end_time = time.time()

                print(f"\t\t---- ----测试循环{Test_Case}----会话任务{list_item}结束---- ----")
                print(f"\t\t---- ----任务时间: {task_end_time - task_run_time:.6f} 秒\n\n")  

            loop_end_time = time.time()
            print(f"\t\t%%%% %%%%测试循环{Test_Case}结束%%%% %%%%\n")
            print(f"\t\t%%%% %%%%循环时间: {loop_end_time - loop_run_time:.6f} 秒")  

                
        input("Press Enter to Contin")





if __name__ == "__main__":
    Cards = Agile_Elaberate()
    Cards[0].Agile_LLMB_Infer()

