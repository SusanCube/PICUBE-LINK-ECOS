import time
from config import *
from pcie_base_task import *
from root_tune_link import *
from pcie_link_util import *
from pcie_llmb_task import *

class PCIe_CORE(LINK_UTIL, PCIe_LLMB, ROOT_TUNE_LINK, PCIe_Base):

    def __init__(self, cid):
        PCIe_Base.__init__(self, cid)
        

