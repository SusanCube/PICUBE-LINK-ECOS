import time
from config import *
from pcie_llmb_task import *

SaveLog = []
LogQuit = []
LogQuitStr = []


def util_read_from_img(fname):
    rf = open(f"{fname}", "rb")
    ls = rf.read()
    rf.close()
    ls = list(ls)
    return ls

def util_alignment(ls, ALIGN=4, tail=0):
    leng = len(ls)
    left = leng % (ALIGN)
    #self.DEBUG4(f"util_alignment    {leng} + {left} = {leng+left} bytes")
    if left > 0:
        ls += [tail]*(ALIGN-left)
    ols = []
    i = 0
    #self.DEBUG4(f"util_alignment    {int((leng+left)/ALIGN)} works")
    while (i<int((leng+left)/ALIGN)):
        tmp = 0
        for j in range(ALIGN):
            tmp = (tmp << 8) + ls[i*ALIGN+(ALIGN-1-j)]
        ols.append(tmp)
        i += 1
    #self.DEBUG4(f"total {i} word")
    return ols

########################################################################################################
def malloc_file_memo(fileName):
    file_memo = []    
   
    with open(fileName, 'rb') as f:
        file_memo = bytearray(f.read())
    return file_memo
########################################################################################################
def writ_hex4_file(filename,data):
    if len(data) % 4 != 0:
        print(f"FILE::{filename} SIZE::{len(data):08X} ISN'T multiple of 4!!!,Quit Now!!!")
        return
    
    with open(filename, 'w') as f:
        for i in range(0, len(data), 4):
            b0, b1, b2, b3 = data[i:i+4]
            word = (b3 << 24) | (b2 << 16) | (b1 << 8) | b0
            f.write(f"{word:08x}\n")
########################################################################################################
def binary_hex4_file(img_file):
    """将二进制文件转换为hex4格式 hex4格式：每4字节作为一个小端序的32位整数，转换成8位十六进制字符串，每行一个值        
    参数:
        img_file: 输入的二进制文件路径（如 "A.img"）
    返回:
        输出的hex4文件路径（如 "A.pcie_rstn_tpgshex4"）
    """
    # 生成输出文件名
    if img_file.endswith('.img'):
        hex4_file = img_file[:-4] + '.hex4'
    else:
        hex4_file = img_file + '.hex4'
    # 读取二进制文件
    with open(img_file, 'rb') as rf:
        data = rf.read()
    # 转换为hex4格式
    hex_lines = []
    bytes_per_word = 4
    num_words = len(data) // bytes_per_word
    remainder = len(data) % bytes_per_word
    # 处理完整的4字节组
    for i in range(num_words):
        # 小端序：从低字节到高字节组合
        value = 0
        for j in range(bytes_per_word):
            value |= data[i * bytes_per_word + j] << (j * 8)
        # 转换为8位十六进制字符串（小写）
        hex_str = f"{value:08X}"
        hex_lines.append(hex_str)
    # 处理剩余的字节（不足4字节的情况）
    if remainder > 0:
        value = 0
        for j in range(remainder):
            value |= data[num_words * bytes_per_word + j] << (j * 8)
        # 转换为8位十六进制字符串（小写）
        hex_str = f"{value:08x}"
        hex_lines.append(hex_str)
    
    # 写入hex4文件
    with open(hex4_file, 'w') as wf:
        for hex_str in hex_lines:
            wf.write(hex_str + '\n')
    print("Write HEX4 Done!")        
    
    return hex4_file




#def pile_confirm(piles, vals, stopVal=0):
#    pass_flag = 1
#    for pile in piles:
#        #self.DEBUG4(pile)
#        ret = edge_confirm(pile, vals, stopVal)
#        if ret == 0:
#            pass_flag = 0
#            break
#        if ret <  0:
#            pass_flag = -1
#            break
#        #self.DEBUG4(pass_flag)
#    return pass_flag
#
#def edge_confirm(edges, vals, stopVal=0):
#    pass_flag = 1
#    for edgeInx in EE:
#        passF = 0
#        for val in vals:
#            if (edges[edgeInx-E0] & val) == val:
#                passF = 1
#        if stopVal != 0 and (edges[edgeInx-E0] & stopVal) == stopVal:
#            pass_flag = -1
#            break
#        if (passF == 0):
#            pass_flag = 0
#            break
#        #self.DEBUG4(f"{edgeInx} {hex(edges[edgeInx-E0])} {hex(val)}")
#    return pass_flag