import time
from config import *
from config_ecos import *

from pcie_base_task import *
from pcie_core_func import *
from base_core_util import *
from llmb_infer_task    import *
from datetime import datetime as dt

from    transformers import AutoTokenizer

import  numpy as np
#import subprocess

Tokenizers_PATH  = "./database/tokenizer/Qwen3_4B_Tokenizers"
Vocabulary_FILE  = "./database/tokenizer/Qwen3_4B_Vocabulary.bin"


#Tokenizer_PATH  = "../../../weights/Qwen3/Qwen3-4B/Qwen3-4B-Tokenizer"
#Vocabulary      = "../../../weights/Qwen3/Qwen3-4B/Qwen3-4B-Dict/embed_tokens/weight.img"

 #   result=subprocess.run(['pwd'], capture_output=True, text=True)
 #   print(result.stdout)
  
if 1:
    tokenizer = AutoTokenizer.from_pretrained(Tokenizers_PATH)
    fbin = open(Vocabulary_FILE, 'rb')
    array = fbin.read()
    print(f"Vocabulary {Vocabulary_FILE} len(array) {len(array)}")
    VCBRBook = np.frombuffer(array, dtype=np.float16).reshape(VCBRNormSize, ToknEmbdSize).astype(np.float16)
    n_Voc = len(VCBRBook)
    print(f"here VCBRBook {len(VCBRBook)} {n_Voc}")

class LLMB_INFER_ECOS(LLMB_INFER_TASK,PCIe_CORE):

    def __init__(self):
        pass
###################################################################################################
    def coordinator_transform(self,orig_indx):
        rows_indx   =   orig_indx // 51200
        resv_cols   =   orig_indx %  51200

        core_indx   =   resv_cols //    800
        cols_ofst   =   resv_cols %     800

        tran_indx   =   core_indx * 2400 + rows_indx*800 + cols_ofst
        return  tran_indx

    def Refresh_LVDS_intf(self):
        tune_rxdi =1 
        while(tune_rxdi):
            tune_rxdi= self.root_tune_hubs_rxdi()
        print("\t\t\t\t\t~~~~~tune hubs RXDI lanes Done!")
        ##########################################################################################################
        print(">>>>>>>>    STEP:3  ROOT TRIM HUBS TXDO LANES            <<<<<<<<")
        tune_txdo =1 
        while(tune_txdo):
            tune_txdo=self.root_tune_hubs_txdo()
        print("\t\t\t\t\t~~~~~tune hubs TXDO lanes Done!")

###################################################################################################
    def writ_dump_hex4(self,filename,rows,cols):
        ReadDataMemo = bytearray(rows*cols*2)
        self.pcie_rdma_root_ddrs(ReadDataMemo,ROOT_ECOS_DDRS, rows, cols)
        writ_hex4_file(filename,ReadDataMemo)
###################################################################################################    
    def llmb_tokn_decd_info(self,ToknID):    
        info = tokenizer.decode(ToknID, skip_special_tokens=True)
        return info
###################################################################################################
    def llmb_str2_tokn_vect(self,task_qury_list):
        task_qury_info = tokenizer.apply_chat_template(task_qury_list, add_generation_prompt=True, tokenize = False)
        task_qury_tank = tokenizer([task_qury_info])

        task_tokn_indx = task_qury_tank.data['input_ids'][0]
        task_tokn_leng = len(task_tokn_indx)
        task_tokn_vect = [] 
        
        for i in range(task_tokn_leng):
            ids=task_tokn_indx[i]
            data = VCBRBook[ids]           
            task_tokn_vect.append(data)
    
        uint_arry = np.array(task_tokn_vect)
        uint_arry = bytearray(uint_arry.tobytes())
        
        return     uint_arry ,task_tokn_leng,task_tokn_indx
###################################################################################################    
    def llmb_ids2_tokn_vect(self,tokn_indx):
        solo_tokn_vect = VCBRBook[tokn_indx]      
        uint_arry = np.array(solo_tokn_vect)
        uint_arry = bytearray(uint_arry.tobytes())
        return     uint_arry 
###################################################################################################    
    def stream_decode(self, token_id, prev_tokens,printlen,pre):
        ischinese = 0
        current_tokens = prev_tokens + [token_id]
        
        full_text = tokenizer.decode(current_tokens, skip_special_tokens=True)
        str_len = len(full_text)

        if  full_text[-1][-1] =='\n':
            print(full_text[printlen:str_len], end="", flush=True)
            current_tokens = []
            printlen = 0
            pre= 0
            return current_tokens,printlen,pre

        if '\u4e00' <= full_text[-1][-1] <= '\u9fff':
            ischinese = 1
        if ischinese:
            print(full_text[printlen:str_len], end="", flush=True)
            printlen = str_len
        else:
            full_text_spilt = full_text.strip().split(" ")
            now = len(full_text_spilt) - 1
            if now > pre:
                str = " ".join(full_text_spilt[:now])
                print(str[printlen:len(str)], end="", flush=True)
                printlen = len(str)
            pre = now
        return current_tokens,printlen,pre
###################################################################################################    
    def llmb_moni_temp_cnvt(self,dui32):
        data_temp   = dui32 & 0xffff
        dfloat      = data_temp * 160 /1024
        return  dfloat  

###################################################################################################    
    def llmb_moni_temp_wave(self,indx,TempVect):
        temp_word = np.frombuffer(TempVect, dtype=np.uint32)

        temp_mask = 0xffff
        temp_list_npu0 =list(range(32))
        temp_list_npu1 =list(range(32))
        temp_list_ddr0 =list(range(32))
        temp_list_ddr1 =list(range(32))

        temp_pole_npu0 =list(range(32))
        temp_pole_npu1 =list(range(32))
        temp_pole_ddr0 =list(range(32))
        temp_pole_ddr1 =list(range(32))
        

        for i in range(32):
            temp_base = i * 32
            temp_list_npu0[i]   =   self.llmb_moni_temp_cnvt(temp_word[temp_base + 4 ])
            temp_list_npu1[i]   =   self.llmb_moni_temp_cnvt(temp_word[temp_base + 5 ])
            temp_list_ddr0[i]   =   self.llmb_moni_temp_cnvt(temp_word[temp_base + 6 ])
            temp_list_ddr1[i]   =   self.llmb_moni_temp_cnvt(temp_word[temp_base + 7 ])

            temp_pole_npu0[i]   =   self.llmb_moni_temp_cnvt(temp_word[temp_base + 8 ])
            temp_pole_npu1[i]   =   self.llmb_moni_temp_cnvt(temp_word[temp_base + 9 ])
            temp_pole_ddr0[i]   =   self.llmb_moni_temp_cnvt(temp_word[temp_base +10 ])
            temp_pole_ddr1[i]   =   self.llmb_moni_temp_cnvt(temp_word[temp_base +11 ])

        now = dt.now()
        ms = f"{now.microsecond:06d}"[:3]
        time_str = now.strftime("%Y-%m-%d %H:%M:%S") + f":{ms}"

        if DUMP_TEMP:     
            with open('temp_log.txt', 'a', encoding='utf-8') as f:
                print("::", time_str,f"@SSIT_TOKEN::{indx}",file=f)

                print(f"\n----TEMP_NPU0",end="", file=f)    
                for i in range(32):
                    print(f" +{temp_list_npu0[i]:05.2f}@{temp_pole_npu0[i]-40:04.1f}",end="", file=f)    

                print(f"\n----TEMP_NPU1",end="", file=f)    
                for i in range(32):
                    print(f" +{temp_list_npu1[i]:05.2f}@{temp_pole_npu1[i]-40:04.1f}",end="", file=f)    

                print(f"\n----TEMP_DDR0",end="", file=f)    
                for i in range(32):
                    print(f" +{temp_list_ddr0[i]:05.2f}@{temp_pole_ddr0[i]-40:04.1f}",end="", file=f)    

                print(f"\n----TEMP_DDR1",end="", file=f)    
                for i in range(32):
                    print(f" +{temp_list_ddr1[i]:05.2f}@{temp_pole_ddr1[i]-40:04.1f}",end="", file=f)    

                print("\n",file=f)
####vcbr_gnpu_rows ::  vcbr_gnpu_extn_rows########vcbr_gnpu_cols ::  vcbr_gnpu_extn_colss
    def llmb_vbcr_maxi_indx(self,VCBRVect,vcbr_gnpu_numb,vcbr_gnpu_rows,vcbr_gnpu_cols,vcbr_gnpu_size):
        
        tokn_vals = np.frombuffer(VCBRVect, dtype=np.float16)

        vcbr_real_posi  = 0
        vcbr_maxi_vals  = tokn_vals[0]
        vcbr_maxi_posi  = 0

        vcbr_lump_cols  =  vcbr_gnpu_cols *  vcbr_gnpu_numb 
        
        for gnpu_indx in range(vcbr_gnpu_numb) :#64/40/32
            gnpu_sort_bias  =  vcbr_gnpu_cols * gnpu_indx 
            gnpu_real_bias  =  vcbr_gnpu_size * gnpu_indx 
            for rows_indx in range(vcbr_gnpu_rows):#5
                rows_sort_bias  =  vcbr_lump_cols *  rows_indx
                rows_real_bias  =  vcbr_gnpu_cols *  rows_indx
                
                for cols_indx in range(vcbr_gnpu_cols):
                    vcbr_sort_posi  = gnpu_sort_bias + rows_sort_bias + cols_indx
                    vcbr_real_posi  = gnpu_real_bias + rows_real_bias + cols_indx 
                    vcbr_comp_vals =  tokn_vals[vcbr_sort_posi]    
                    
                    if(vcbr_comp_vals > vcbr_maxi_vals):
                        vcbr_maxi_vals   =    vcbr_comp_vals  
                        vcbr_maxi_posi   =    vcbr_real_posi
        
        return vcbr_maxi_vals , vcbr_maxi_posi
###################################################################################################    
    def llmb_infer_solo_tokn(self,tc,infer_posi,infer_leng,model_loop):

        for i in range(model_loop):
            self.llmb_infer_attn(infer_posi,infer_leng,i)
            self.llmb_infer_hint(infer_posi,infer_leng,i)
            self.llmb_infer_ugat(infer_posi,infer_leng,i)
            self.llmb_infer_down(infer_posi,infer_leng,i)
            
        self.llmb_infer_vcbr(0)
###################################################################################################
    def llmb_vcbr_maxi_seek(self,VCBRVect,SortLeng):
        tokn_vals = np.frombuffer(VCBRVect, dtype=np.float16)
        vcbr_maxi_vals  = tokn_vals[0]
        vcbr_maxi_posi  = 0

        for i in range(SortLeng):
            vcbr_comp_vals =  tokn_vals[i]    
            if(vcbr_comp_vals > vcbr_maxi_vals):
                        vcbr_maxi_vals   =    vcbr_comp_vals  
                        vcbr_maxi_posi   =    i

        return vcbr_maxi_vals , vcbr_maxi_posi
###################################################################################################    
    def llmb_vcbr_posi_seek(self,RawsPosi):
        root_dims   =   480 * 64
        rows_indx   =   RawsPosi    // root_dims
        resv_cols   =   RawsPosi    %  root_dims
        core_indx   =   resv_cols   // 480
        cols_ofst   =   resv_cols   %  480
        tokn_indx   =   core_indx * 2400 + rows_indx*480 + cols_ofst
        return  tokn_indx
###################################################################################################
    def stream_decode(self,token_id, prev_tokens,printlen,pre):
        ischinese = 0
        current_tokens = prev_tokens + [token_id]

        full_text = tokenizer.decode(current_tokens, skip_special_tokens=True)
        str_len = len(full_text)

        if  full_text[-1][-1] =='\n':
            print(full_text[printlen:str_len], end="", flush=True)
            current_tokens= []
            printlen = 0
            pre= 0
            return current_tokens,printlen,pre

        if '\u4e00' <= full_text[-1][-1] <= '\u9fff':
            ischinese = 1
        if ischinese:
            print(full_text[printlen:str_len], end="", flush=True)
            printlen = str_len
        else:
            full_text_spilt = full_text.strip().split(" ")
            now = len(full_text_spilt) - 1
            if now > pre:
                str = " ".join(full_text_spilt[:now])
                print(str[printlen:len(str)], end="", flush=True)
                printlen = len(str)
            pre = now
        return current_tokens,printlen,pre
###################################################################################################
    def llmb_infer_solo_task(self,tc,task_vect,task_posi,task_leng,model_loop):
        infer_task_posi  =   task_posi #0
        infer_task_leng  =   task_leng #1
        
        infer_vcbr_memo  =   bytearray(1*VCBRExtnSize*2)
        infer_temp_memo  =   bytearray(1*TEMPExtnSize*2)
        
        infer_tokn_vect  =   task_vect
        prev_tokens = []
        printlen = 0
        pre = 0
        
        infer_task_boot =   1        

        start_time = time.perf_counter()
        infer_tokn = 0
        INFER_MAXI_TOKEN = INFER_MAXI_LENG-infer_task_leng

        for i in range(INFER_MAXI_TOKEN):
    
            self.pcie_wdma_root_ddrs(infer_tokn_vect, ROOT_ECOS_DDRS, infer_task_leng,2560)
            self.llmb_infer_solo_tokn(tc,infer_task_posi,infer_task_leng,model_loop)
            self.pcie_rdma_root_ddrs(infer_vcbr_memo, ROOT_ECOS_DDRS, 1, VCBRExtnSize)
            
            Seek_Vals,Seek_Posi =   self.llmb_vcbr_maxi_seek(infer_vcbr_memo,153600)
            Tokn_Indx           =   self.llmb_vcbr_posi_seek(Seek_Posi)
            prev_tokens,printlen,pre = self.stream_decode(Tokn_Indx,prev_tokens,printlen,pre)
                
            if infer_task_boot:
                infer_task_boot = 0
                end_time = time.perf_counter()
                duration = (end_time - start_time)
                infer_TPS= task_leng/duration
                duration = duration*1000
                print(f"\n********Prefill_Token个数::{task_leng},耗时::{duration:.2f}ms,性能{infer_TPS:.2f}tokens/second.") 

            if (infer_tokn % 40) == 0:
                self.llmb_infer_temp()
                self.pcie_rdma_root_ddrs(infer_temp_memo, ROOT_RDMA_DDRS, 1, TEMPExtnSize)
                self.llmb_moni_temp_wave(infer_tokn,infer_temp_memo)
            

            if(Tokn_Indx in END_TOKEN):
                end_time = time.perf_counter()
                duration = (end_time - start_time)
                infer_TPS= infer_tokn/duration
                duration = duration*1000
                print(f"\n 推理完成,输出词原个数::{infer_tokn},耗时::{duration:.2f}ms,性能{infer_TPS:.2f}tokens/second.")
                return 1
            else:
                infer_tokn_vect =   self.llmb_ids2_tokn_vect(Tokn_Indx)
                infer_task_posi +=  infer_task_leng
                infer_task_leng =   1
                infer_tokn      +=  1
                #self.ms_sleep( 7)
                #end_time = time.perf_counter()
                #duration = (end_time - start_time)*1000
                #start_time =end_time
               # print(f"::{duration:.2f}ms____ID:{Tokn_Indx}__{Seek_Posi}::{Seek_Vals:.02f}@@{infer_task_posi}::{i}.")

        print(f"InferTask Done!!! ")     