import os
import sys
from config import *
from config_ecos import *

from pcie_base_task import *
from pcie_core_func import *
from base_core_util import *
import numpy as np

class LLMB_INFER_TASK(PCIe_CORE):

    def __init__(self):
        pass

    def llmb_dump_gnpu(self,dumpfile,hubs,edge,gnpu,rows,cols,base):
        ReadDataMemo = bytearray(rows*cols*2)
        self.root_ivct_gnpu_ddrs(hubs,edge,gnpu,ROOT_ECOS_DDRS,base,rows,cols)
        self.pcie_rdma_root_ddrs(ReadDataMemo,ROOT_ECOS_DDRS, rows,cols)
        writ_hex4_file(dumpfile,ReadDataMemo)
    
    def llmb_dump_meta(self,dumpfile,rows,cols):
        ReadDataMemo = bytearray(rows*cols*2)
        self.pcie_rdma_root_ddrs(ReadDataMemo,ROOT_ECOS_DDRS, rows,cols)
        writ_hex4_file(dumpfile,ReadDataMemo)

    def llmb_infer_temp(self) :
        self.root_rimt_gnpu_ddrs(gnpu =0 , madd=ROOT_RDMA_DDRS, sadd=0X4000, rows=1, cols=32,dims=2048)
        self.root_rsim_hubs_ddrs(root_rows=1 , root_addr=ROOT_RDMA_DDRS  , root_cols=2048//16, hubs_bias=512*1//16,  hubs_cols=512//16, hubs_dmmy=0, p=1)
        self.root_rsim_hubs_ddrs(root_rows=1 , root_addr=ROOT_RDMA_DDRS  , root_cols=2048//16, hubs_bias=512*2//16,  hubs_cols=512//16, hubs_dmmy=0, p=2)
        self.root_rsim_hubs_ddrs(root_rows=1 , root_addr=ROOT_RDMA_DDRS  , root_cols=2048//16, hubs_bias=512*3//16,  hubs_cols=512//16, hubs_dmmy=0, p=3)


    def llmb_infer_attn(self,Posi,Rows,Loop):
        if EXEC_OMTX:
            self.root_omtx_gnpu_ddrs(hubs=0xF, edge=0XFF ,gnpu=0X2, madd=ROOT_ECOS_DDRS, sadd=ATTN_INPP_BASE, rows=Rows, cols=2560)
        if EXEC_NNEX:
            self.root_nnex_gnpu_task(Posi, Rows, Loop, NNEX_RMSNorm)
        if EXEC_RIMT:
            self.root_rimt_gnpu_ddrs(gnpu =0 , madd=ROOT_ECOS_DDRS, sadd=ATTN_OUTP_BASE, rows=Rows, cols=128,dims=4096)
            self.root_rimt_gnpu_ddrs(gnpu =1 , madd=ROOT_ECOS_DDRS, sadd=ATTN_OUTP_BASE, rows=Rows, cols=128,dims=4096)
        if EXEC_RISM:
            self.root_rsim_hubs_ddrs(root_rows=Rows , root_addr=ROOT_ECOS_DDRS  , root_cols=4096//16, hubs_bias=2048//16,  hubs_cols=2048//16   , hubs_dmmy=0, p=1)
            
        if DUMP_ATTN:
            dumpfile = f"./dump_data/ATTN_LOOP{Loop}_RISM.hex"
            self.llmb_dump_meta(dumpfile,26,4096)
       
    def llmb_infer_hint(self,Posi,Rows,Loop):
        if EXEC_OMTX:
            self.root_omtx_gnpu_ddrs(hubs=0xF, edge=0XFF ,gnpu=0X2, madd=ROOT_ECOS_DDRS, sadd=HINT_INPP_BASE, rows=Rows, cols=4096)
        if EXEC_NNEX:
            self.root_nnex_gnpu_task(Posi, Rows, Loop, NNEX_OGemm)
            #dumpfile = f"./dump_data/HINT_LOOP{Loop}_OMTX_H1E0G1.hex"
            #self.llmb_dump_gnpu(dumpfile,1,0,1,45,64,HINT_OUTP_BASE)
        if EXEC_RIMT:
            self.root_rimt_gnpu_ddrs(gnpu =0 , madd=ROOT_ECOS_DDRS, sadd=HINT_OUTP_BASE, rows=Rows, cols=64,dims=2560)
            self.root_rimt_gnpu_ddrs(gnpu =1 , madd=ROOT_ECOS_DDRS, sadd=HINT_OUTP_BASE, rows=Rows, cols=64,dims=2560)
        if EXEC_RISM:
            self.root_rsim_hubs_ddrs(root_rows=Rows , root_addr=ROOT_ECOS_DDRS  , root_cols=2560//16, hubs_bias=1024//16,  hubs_cols=1024//16, hubs_dmmy=0      , p=1)
            self.root_rsim_hubs_ddrs(root_rows=Rows , root_addr=ROOT_ECOS_DDRS  , root_cols=2560//16, hubs_bias=2048//16,  hubs_cols= 512//16, hubs_dmmy=512//16, p=2)
        if DUMP_HINT:
            dumpfile = f"./dump_data/HINT_LOOP{Loop}_RISM.hex"
            self.llmb_dump_meta(dumpfile,26,2560)

    def llmb_infer_ugat(self,Posi,Rows,Loop):
        if EXEC_OMTX:
            self.root_omtx_gnpu_ddrs(hubs=0xF, edge=0XFF ,gnpu=0X2, madd=ROOT_ECOS_DDRS, sadd=UGAT_INPP_BASE, rows=Rows, cols=2560)
        if EXEC_NNEX:
            self.root_nnex_gnpu_task(Posi, Rows, Loop, NNEX_RMSNormMid)
        if EXEC_RIMT:
            self.root_rimt_gnpu_ddrs(gnpu =0 , madd=ROOT_ECOS_DDRS, sadd=UGAT_OUTP_BASE, rows=Rows, cols=160,dims=9728)
            self.root_rimt_gnpu_ddrs(gnpu =1 , madd=ROOT_ECOS_DDRS, sadd=UGAT_OUTP_BASE, rows=Rows, cols=160,dims=9728)
        if EXEC_RISM:
            self.root_rsim_hubs_ddrs(root_rows=Rows , root_addr=ROOT_ECOS_DDRS  , root_cols=9728//16, hubs_bias=2560//16,  hubs_cols=2560//16, hubs_dmmy=0      , p=1)
            self.root_rsim_hubs_ddrs(root_rows=Rows , root_addr=ROOT_ECOS_DDRS  , root_cols=9728//16, hubs_bias=5120//16,  hubs_cols=2560//16, hubs_dmmy=0      , p=2)
            self.root_rsim_hubs_ddrs(root_rows=Rows , root_addr=ROOT_ECOS_DDRS  , root_cols=9728//16, hubs_bias=7680//16,  hubs_cols=2048//16, hubs_dmmy=512//16, p=3)
        if DUMP_UGAT:    
            dumpfile = f"./dump_data/UGAT_LOOP{Loop}_RISM.hex"
            self.llmb_dump_meta(dumpfile,26*19,512)

    def llmb_infer_down(self,Posi,Rows,Loop):
        if EXEC_OMTX:
            self.root_omtx_gnpu_ddrs(hubs=0xF, edge=0XFF ,gnpu=0X2, madd=ROOT_ECOS_DDRS, sadd=DOWN_INPP_BASE, rows=Rows, cols=9728)
        if EXEC_NNEX:
            self.root_nnex_gnpu_task(Posi, Rows, Loop, NNEX_LongGemm)
        if Loop == INFER_MLPS_LOOP - 1:
            DOWN_OUTP_OFST = 64 * (Rows - 1) // 32    
            DOWN_OUTP_ADDR = DOWN_OUTP_BASE +  DOWN_OUTP_OFST  
            DOWN_OUTP_ROWS = 1
        else :
            DOWN_OUTP_ADDR = DOWN_OUTP_BASE 
            DOWN_OUTP_ROWS = Rows
        if EXEC_RIMT:
            self.root_rimt_gnpu_ddrs(gnpu =0 , madd=ROOT_ECOS_DDRS, sadd=DOWN_OUTP_ADDR, rows=DOWN_OUTP_ROWS, cols=64,dims=2560)
            self.root_rimt_gnpu_ddrs(gnpu =1 , madd=ROOT_ECOS_DDRS, sadd=DOWN_OUTP_ADDR, rows=DOWN_OUTP_ROWS, cols=64,dims=2560)
        if EXEC_RISM:
            self.root_rsim_hubs_ddrs(root_rows=DOWN_OUTP_ROWS , root_addr=ROOT_ECOS_DDRS , root_cols=2560//16, hubs_bias=1024//16,  hubs_cols=1024//16, hubs_dmmy=0      , p=1)
            self.root_rsim_hubs_ddrs(root_rows=DOWN_OUTP_ROWS , root_addr=ROOT_ECOS_DDRS , root_cols=2560//16, hubs_bias=2048//16,  hubs_cols= 512//16, hubs_dmmy=512//16, p=2)
        if DUMP_DOWN:    
            dumpfile = f"./dump_data/DOWN_LOOP{Loop}_RISM.hex"
            self.llmb_dump_meta(dumpfile,26,2560)

    def llmb_infer_vcbr(self,Posi):
        if EXEC_OMTX:
            self.root_omtx_gnpu_ddrs(hubs=0xF, edge=0XFF ,gnpu=0X2, madd=ROOT_ECOS_DDRS, sadd=VCBR_INPP_BASE, rows=1, cols=2560)
        if EXEC_NNEX:
            self.root_nnex_gnpu_task(Posi, 1, 0, NNEX_RMSNormFinal)
        if EXEC_RIMT:
            root_dims = 480*64
            hubs_dims = 480*16
            self.root_rimt_gnpu_ddrs(gnpu =0 , madd=ROOT_ECOS_DDRS, sadd=VCBR_OUTP_BASE, rows=5, cols=480,dims=root_dims)
            self.root_rimt_gnpu_ddrs(gnpu =1 , madd=ROOT_ECOS_DDRS, sadd=VCBR_OUTP_BASE, rows=5, cols=480,dims=root_dims)
        if EXEC_RISM:
            self.root_rsim_hubs_ddrs(root_rows=5 ,      root_addr=ROOT_ECOS_DDRS , root_cols=root_dims//16, hubs_bias=hubs_dims*1//16,  hubs_cols=hubs_dims//16, hubs_dmmy=0  , p=1)
            self.root_rsim_hubs_ddrs(root_rows=5 ,      root_addr=ROOT_ECOS_DDRS , root_cols=root_dims//16, hubs_bias=hubs_dims*2//16,  hubs_cols=hubs_dims//16, hubs_dmmy=0  , p=2)
            self.root_rsim_hubs_ddrs(root_rows=5 ,      root_addr=ROOT_ECOS_DDRS , root_cols=root_dims//16, hubs_bias=hubs_dims*3//16,  hubs_cols=hubs_dims//16, hubs_dmmy=0  , p=3)
        
        #if DUMP_VCBR:    
        #    dumpfile = f"./dump_data/VCBR_POSI{Posi}_RISM.hex"
        #    self.llmb_dump_meta(dumpfile,5,root_dims)

        #if EXEC_RIMT:
        #   root_dims = 800*64
        #   hubs_dims = 800*16
        #   self.root_rimt_gnpu_ddrs(gnpu =0 , madd=ROOT_ECOS_DDRS, sadd=VCBR_OUTP_BASE, rows=3, cols=800,dims=root_dims)
        #   self.root_rimt_gnpu_ddrs(gnpu =1 , madd=ROOT_ECOS_DDRS, sadd=VCBR_OUTP_BASE, rows=3, cols=800,dims=root_dims)
        #if EXEC_RISM:
        #   self.root_rsim_hubs_ddrs(root_rows=5 ,      root_addr=ROOT_ECOS_DDRS , root_cols=root_dims//16, hubs_bias=hubs_dims*1//16,  hubs_cols=hubs_dims//16, hubs_dmmy=0  , p=1)
        #   self.root_rsim_hubs_ddrs(root_rows=5 ,      root_addr=ROOT_ECOS_DDRS , root_cols=root_dims//16, hubs_bias=hubs_dims*2//16,  hubs_cols=hubs_dims//16, hubs_dmmy=0  , p=2)
        #   self.root_rsim_hubs_ddrs(root_rows=5 ,      root_addr=ROOT_ECOS_DDRS , root_cols=root_dims//16, hubs_bias=hubs_dims*3//16,  hubs_cols=hubs_dims//16, hubs_dmmy=0  , p=3)
