import os
import sys
import time
import random
from datetime import datetime as dt

from config import *
from pcie_llmb_task import *
from pcie_base_task import *

from base_core_util import *
from pcie_core_func import *
#from agile_llmb_test import *

from gnpu_misc_task import *

from generate_down_weight_config_json import *

DDR_Retry = 0

        
def Agile_Elaberate():
    N = 0
    AgileCard = []
    #if FakePcie == 0:
    print(f"Card {len(AgileCard)}")
    for i in range(Max_Card_Num):
        fileName = f"/dev/chiprise{i}_user"
        if os.path.exists(fileName):
            AgileCard.append(Agile_LLMB_INIT(i))
            N += 1
        else:
            break
    #else:
    #    AgileCard.append(Agile_LLMB_INIT(0))
    return AgileCard


class Agile_LLMB_INIT(PCIe_CORE,GNPU_MISC_TASK):
    def __init__(self, cid):
    #    init =1 
        PCIe_CORE.__init__(self, cid)
########################################################################################################
    def root_down_hubs_fmwr(self, code,  portMsk):
        self.pcie_cfig_cmnd(portMsk, 1, 0, 0)
        self.pcie_issu_cmnd(LLMB_ASET_CMND)
        self.pcie_down_load(code,0,1)
        self.pcie_issu_cmnd(LLMB_BOOT_CMND)
########################################################################################################
    def root_boot_hubs_fmwr(self):
        code = util_read_from_img(HUBS_ECOS_FILE)
        code = util_alignment(code)
        self.root_down_hubs_fmwr(code, 0XF0000)
        
        return PASS_FLAG
########################################################################################################    
    def root_down_fpga_bitf(self, bitf, portMsk):
        self.pcie_cfig_cmnd(portMsk, 6, 0, 0, 0, 0, 0, 0, 0)
        self.pcie_issu_cmnd(LLMB_ASET_CMND)
        self.pcie_down_load(bitf,1)
        self.pcie_issu_cmnd(LLMB_BOOT_CMND)
########################################################################################################    
    def root_boot_edge_fpga(self):
        bitf = util_read_from_img(CUBE_BITS_FILE)
        bitf = util_alignment(bitf)
        self.root_down_fpga_bitf(bitf, 0XF00FF)
        return PASS_FLAG
########################################################################################################    
    def host_bist_root_ddrs(self,loop,rows,cols):
        WritFileName = f"./stim_data/root_r{rows}_c{cols}.bin"
        WritDataMemo = malloc_file_memo(WritFileName)
        ReadDataMemo = bytearray(rows*cols*2)

        print(f"ROOT DDRS BIST@Rows{rows:08x}&Cols{cols:08x}  Start")
              
            #  'S LOOP~{i:08X}@ADDR::{addr_ddrs:08X}",end="")
            
        for i in range(loop):
            root_rand = random.randint(1, 128)
            root_addr = 0x10000*root_rand
            #root_addr = 0
            self.pcie_wdma_root_ddrs(  WritDataMemo,root_addr, rows, cols)
            self.pcie_rdma_root_ddrs(  ReadDataMemo,root_addr, rows, cols)

            print(f"\tROOT_DDRS_BIST_LOOP_{i:08d}@Root_addr{root_addr:08x} ...",end="")

            if(ReadDataMemo!= WritDataMemo):
                ReadBAckFile =  f"./test_read/BISTROOT_ReadErrs_Loop{i:08d}.hex"
                writ_hex4_file(ReadBAckFile,ReadDataMemo)
                input(f"\t\tXXXX:XXXX:XXXX:XXXX:    HOST_XDMA_ROOT BIST Failed!!!")      
            else:
                print(f"\t\t====:====:====:====:    HOST_XDMA_ROOT BIST Pass,Continue...\n")     
        
        print(f"====:====:====:====:HOST BIST ROOT DDR LOOP::{loop:08d}PASS!")     
########################################################################################################
    def host_bist_hubs_ddrs(self,hubs,loop,rows,cols):
        ReadDataMemo = bytearray(rows*cols*2)
        WritFileName = f"./stim_data/hub{hubs}_r{rows}_c{cols}.bin"
        WritDataMemo = malloc_file_memo(WritFileName)
        print(f"HUBS_PORT_{hubs} DDRS BIST@Rows{rows:08x}&Cols{cols:08x} Start")        

        for i in range(loop):

            root_wrnd = random.randint(1, 128)
            root_wadd = 0x1000*root_wrnd
            
            root_rrnd = random.randint(1, 128)
            root_radd = 0x1000*root_rrnd

        #    hubs_rand  = random.randint(1, 128)
        #    hubs_addr  = 0x1000*hubs_rand
            hubs_addr  = 0x10000
        #    root_wadd = 0x00100000
        #    root_radd = 0x00200000
            

            print(f"\t(H{hubs})_LOOP_{i:04x} root_wadd::{root_wadd:08x}|hubs_addr{hubs_addr:08x}|root_radd{root_radd:08x}|",end="")        

            self.pcie_wdma_root_ddrs(WritDataMemo   ,root_wadd  , rows  , cols  )
            self.root_ovct_hubs_ddrs( root_wadd     ,hubs_addr  , rows  , cols  ,hubs)
            self.root_ivct_hubs_ddrs( root_radd     ,hubs_addr  , rows  , cols  ,hubs)
            self.pcie_rdma_root_ddrs(ReadDataMemo   ,root_radd  , rows  , cols  )

            if(ReadDataMemo!= WritDataMemo):
                print("\t\tCompare Failed\n")     
                ReadDataFile =  f"./bist_data/HUB{hubs}_r{rows}_c{cols}_Loop{i:04x}_Errs.hex4"
                writ_hex4_file(ReadDataFile,ReadDataMemo)
                input(f"\t\tXXXX:XXXX:XXXX:XXXX: ROOT_XVCT_HUB{hubs} BIST Failed!!!")    
            else:
                print(f"\t\t====:====:====:====: ROOT_XVCT_HUB{hubs} BIST Pass,Continue...\n")     

        print(f"HOST BIST HUBS{hubs} DDR PASS!")     
########################################################################################################
    def host_bist_mgth_ddrs(self,loop,rows,root_cols,hubs_cols):
        
        hubs_numb = root_cols // hubs_cols
        hubs_last = root_cols %  hubs_cols  

        if hubs_last != 0:
            hubs_dmmy  =   hubs_cols  - hubs_last
        else:
            hubs_dmmy = 0    

        root_addr = 0x0
        print(f"\tRISM BIST LOOP::{loop:08d}----------------------------------------------")
        print(f"\t\tRISM--|root_addr::{root_addr:08x}|root_cols::{root_cols:05x}|hubs_used::{hubs_numb:01x}|hubs_last::{hubs_last:04x}|hubs_dmmy::{hubs_dmmy:04x}")    
            
        for i in range(1,hubs_numb):
            print(f"\tROOT_OVCT_Hub{i}_Pattern::ROWS{rows:08x}&COLS{hubs_cols:08x}")
            WritFileName = f"./stim_data/hub{i}_r{rows}_c{hubs_cols}.bin"
            WritDataMemo = malloc_file_memo(WritFileName)

            self.pcie_wdma_root_ddrs(WritDataMemo   ,root_addr  , rows  , hubs_cols  )
            self.root_ovct_hubs_ddrs( root_addr     ,root_addr  , rows  , hubs_cols  ,  i   )
        
        print(f"\tHOST_WDMA_Root_Pattern::ROWS{rows:08x}&COLS{(root_cols):08x}")
        WritFileName = f"./stim_data/root_r{rows}_c{root_cols}.bin"
        WritDataMemo = malloc_file_memo(WritFileName)
        self.pcie_wdma_root_ddrs(WritDataMemo   ,root_addr  , rows  , root_cols  )
        
        rism_root_cols = int(  root_cols/16)
        rism_hubs_page = int(  hubs_cols/16)
        rism_hubs_dmmy = int(  hubs_dmmy/16)
        rism_hubs_vlid = rism_hubs_page - rism_hubs_dmmy

        for i in range(1,hubs_numb):
            rism_hubs_bias = int(i*rism_hubs_page)
            
            if(i==hubs_numb-1)    :    
                self.root_rsim_hubs_ddrs(rows, root_addr, rism_root_cols , rism_hubs_bias,     rism_hubs_vlid, rism_hubs_dmmy , p=i)
            else:
                self.root_rsim_hubs_ddrs(rows, root_addr, rism_root_cols , rism_hubs_bias,     rism_hubs_page, 0X0 , p=i)
                
        ReadDataMemo = bytearray(rows*root_cols*2)
        self.pcie_rdma_root_ddrs(ReadDataMemo   ,root_addr  , rows  , root_cols  )

        GoldFileName = f"./stim_data/root_r{rows}_c{root_cols}.ref"
        GoldDataMemo = malloc_file_memo(GoldFileName)

        if(ReadDataMemo!= GoldDataMemo):
            ReadDataFile =  f"./bist_data/ROOT_RISM_READ.hex{loop:04x}"
            writ_hex4_file(ReadDataFile,ReadDataMemo)
            print(f"\t\tXXXX:XXXX:XXXX:XXXX:    ROOT_RISM_HUBS BIST Failed!")     
            input("MGTH DDRS TEST FAILED")    
        else:    
            print(f"\t\t====:====:====:====:    ROOT_RISM_HUBS BIST Pass,Continue...\n")     
########################################################################################################
    def	root_ovct_gnpu_bist(self,rows,cols):
        ReadDataMemo = bytearray(rows*cols*2)
        WritFileName = f"./stim_data/gnpu_r{rows}_c{cols}.bin"
        WritDataMemo = malloc_file_memo(WritFileName)
        print(f"ROOT BIST(OVCT) GNPU DDRS @Rows{rows:08x}&Cols{cols:08x} Start")
		
        for hubs in range(4):
            for edge in range(8):
                root_wadd = 0x10000
                root_radd = 0x100000
                gnpu_rnda = random.randint(1, 128)
                gnpu_addr = 0x1000*gnpu_rnda
                
                print(f"\troot_wadd::{root_wadd:08x}|gnpu_addr{gnpu_addr:08x}|root_radd{root_radd:08x}|",end="")        
                self.pcie_wdma_root_ddrs(WritDataMemo   ,root_wadd  , rows  , cols  )
                self.pcie_rdma_root_ddrs(ReadDataMemo   ,root_wadd  , rows  , cols  )
                    
                if(ReadDataMemo!= WritDataMemo):
                    print(f"\t\tREFERENCE DATA Error!")     
                    ReadDataFile =  f"./test_read/GNPU_OVCT_DSRC_Errs.hex4"
                    writ_hex4_file(ReadDataFile,ReadDataMemo)
                    input(f"----XXXX----Halting... Press ENTER")    
                else:
                    print(f"\t\tREFERENCE DATA Good!")     
                    for gnpu in range(2):
                        print(f"\t\t\tH{hubs:01d}:E{edge:01d}:GNPU{gnpu:01d}: ROOT_OVCT_GNPU BIST----",end="")                          #input("XVCT,Press ENTER")
                        self.root_ovct_gnpu_ddrs( hubs ,edge , gnpu , root_wadd  , gnpu_addr  ,  rows , cols )                        #input("IVCT,Press ENTER")
                        self.root_ivct_gnpu_ddrs( hubs ,edge , gnpu , root_radd  , gnpu_addr  ,  rows , cols )
                        self.pcie_rdma_root_ddrs(ReadDataMemo   ,root_radd  , rows  , cols  )

                        if(ReadDataMemo!= WritDataMemo):
                            ReadDataFile =  f"./test_read/GNPU_OVCT_HUBS({hubs:01d})_EDGE({edge:02d})_GNPU({gnpu:01d})_Errs.hex4"
                            writ_hex4_file(ReadDataFile,ReadDataMemo)
                            input(f"Failed----Halting... Press ENTER")    
                        else:
                            print(f"Pass,Continue...")     

        print(f"ROOT BIST(OVCT) GNPU_DDR PASS!")      
########################################################################################################
    def	omtx_tile_gnpu_bist(self,loop,rows,cols):
        CompFileName = f"./stim_data/omtx_tile/omtx_r{rows}_c{cols}.bin"
        CompDataMemo = malloc_file_memo(CompFileName)

        print(f"GNPU DDRS OMTX_BIST_LOOP({loop:08d})@Rows{rows:08x}&Cols{cols:08x} Start")

        root_wadd = 0x0
        root_radd = 0x0
        
        gnpu_rnda = random.randint(1, 128)
        gnpu_addr = 0x1000*gnpu_rnda
                
        ReadDataMemo = bytearray(rows*cols*2)
        WritFileName = f"./stim_data/omtx_tile/gnpu_r{rows}_c{cols}.bin"
        WritDataMemo = malloc_file_memo(WritFileName)

        print(f"\troot_wadd::{root_wadd:08x}|gnpu_addr::{gnpu_addr:08x}|root_radd::{root_radd:08x}|",end="")        
        self.pcie_wdma_root_ddrs(WritDataMemo   ,root_wadd  , rows  , cols  )
        self.pcie_rdma_root_ddrs(ReadDataMemo   ,root_wadd  , rows  , cols  )

        if(ReadDataMemo!= WritDataMemo):
            print(f"\t\tREFERENCE DATA Error!")     
            ReadDataFile =  f"./test_read/GNPU_XVCT_DSRC_Errs.hex4"
            writ_hex4_file(ReadDataFile,ReadDataMemo)
            input(f"----XXXX----Halting... Press ENTER")    
        else:
            print(f"\t\tGNPU_OMTX REFERENCE DATA Good,start Test!")     
            self.root_omtx_gnpu_ddrs( 0XF ,0XFF , 0X2 , root_wadd  , gnpu_addr  ,  rows , cols )                        
                        

        for hubs in range(4):
            for edge in range(8):
                for gnpu in range(2):
                    print(f"\t\t\tH{hubs:01d}:E{edge:01d}:GNPU{gnpu:01d}: ROOT_OMTX_GNPU_META ReadBack ",end="")                          #input("XVCT,Press ENTER")
                    self.root_ivct_gnpu_ddrs( hubs ,edge , gnpu , root_radd  , gnpu_addr  ,  rows , cols )
                    self.pcie_rdma_root_ddrs(ReadDataMemo   ,root_radd  , rows  , cols  )
                    
                    if(ReadDataMemo!= CompDataMemo):
                        print(f"\t\tH{hubs:01d}:E{edge:01d}:GNPU{gnpu:01d}: ROOT_OMTX_GNPU BIST Failed\n")     
                        ReadDataFile =  f"./test_read/GNPU_OMTX_TILE_[HUBS({hubs:01d})_EDGE({edge:02d})_GNPU({gnpu:01d})]_Errs.hex4"
                        writ_hex4_file(ReadDataFile,ReadDataMemo)
                        input(f"Failed----Halting... Press ENTER\n")    
                    else:
                        print(f"Pass,Continue...\n")      
        print(f"ROOT BIST(OMTX) GNPU_DDR PASS!")     
########################################################################################################
    def	omtx_rect_gnpu_bist(self,rows,cols):
        ReadDataMemo = bytearray(rows*cols*2)
        WritFileName = f"./stim_data/omtx_rect/raws_r{rows}_c{cols}.bin"
        WritDataMemo = malloc_file_memo(WritFileName)

        CompFileName = f"./stim_data/omtx_rect/omtx_r{rows}_c{cols}.bin"
        CompDataMemo = malloc_file_memo(CompFileName)
        
        print(f"BIST_OMTX_RECT => GNPU_DDRS @Rows{rows:08x}&Cols{cols:08x} Start")
		
        for hubs in range(4):
            for edge in range(8):
                root_wadd = 0x10000
                root_radd = 0x100000

                gnpu_rnda = random.randint(1, 128)
                gnpu_addr = 0x1000*gnpu_rnda
                
                print(f"\troot_wadd::{root_wadd:08x}|gnpu_addr::{gnpu_addr:08x}|root_radd::{root_radd:08x}|",end="")        
                self.pcie_wdma_root_ddrs(WritDataMemo   ,root_wadd  , rows  , cols  )
                self.pcie_rdma_root_ddrs(ReadDataMemo   ,root_wadd  , rows  , cols  )
                    
                if(ReadDataMemo!= WritDataMemo):
                    print(f"\t\tREFERENCE DATA Error!")     
                    ReadDataFile =  f"./test_read/GNPU_XVCT_DSRC_Errs.hex4"
                    writ_hex4_file(ReadDataFile,ReadDataMemo)
                    input(f"----XXXX----Halting... Press ENTER")    
                else:
                    print(f"\t\tREFERENCE DATA Good!")     
                    for gnpu in range(2):
                        print(f"\t\t\tH{hubs:01d}:E{edge:01d}:GNPU{gnpu:01d}: ROOT_OMTX_GNPU BISTING ",end="")                          #input("XVCT,Press ENTER")
                        self.root_omtx_gnpu_ddrs( hubs ,edge , gnpu , root_wadd  , gnpu_addr  ,  rows , cols )                        #input("IVCT,Press ENTER")
                        self.root_ivct_gnpu_ddrs( hubs ,edge , gnpu , root_radd  , gnpu_addr  ,  rows , cols )
                        self.pcie_rdma_root_ddrs(ReadDataMemo   ,root_radd  , rows  , cols  )
                        
                        if(ReadDataMemo!= CompDataMemo):
                            print(f"\t\tH{hubs:01d}:E{edge:01d}:GNPU{gnpu:01d}: ROOT_OMTX_GNPU BIST Failed\n")     
                            ReadDataFile =  f"./test_read/GNPU_OMTX_RECT_[HUBS({hubs:01d})_EDGE({edge:02d})_GNPU({gnpu:01d})]_Errs.hex4"
                            writ_hex4_file(ReadDataFile,ReadDataMemo)
                            input(f"Failed----Halting... Press ENTER\n")    
                        else:
                            print(f"Pass,Continue...\n")      
        print(f"ROOT BIST(OMTX) GNPU_DDR PASS!")     
########################################################################################################
    def	root_rimt_gnpu_bist(self,rows,cols):
        root_wadd = 0x10000
        root_radd = 0x100000
        gnpu_addr = 0x100000

        ReadGnpuMemo = bytearray(rows*cols*2)

        
        for hubs in range(4):
            for edge in range(8):
                for gnpu in range(2):
                    WritFileName = f"./stim_data/rimt/rimt_h{hubs:01d}_e{edge:01d}_g{gnpu:01d}_r{rows}_c{cols}.bin"    
                    WritDataMemo = malloc_file_memo(WritFileName)

                    self.pcie_wdma_root_ddrs(WritDataMemo   ,root_wadd  , rows  , cols  )
                    self.root_ovct_gnpu_ddrs(hubs ,edge , gnpu , root_wadd  , gnpu_addr  ,  rows , cols )                        #input("IVCT,Press ENTER")
                    self.root_ivct_gnpu_ddrs(hubs ,edge , gnpu , root_radd  , gnpu_addr  ,  rows , cols )
                    self.pcie_rdma_root_ddrs(ReadGnpuMemo   ,root_radd  , rows  , cols  )

                    if(ReadGnpuMemo!= WritDataMemo):
                        ReadDataFile =  f"./test_read/GNPU_OMTX_HUBS({hubs:01d})_EDGE({edge:02d})_GNPU({gnpu:01d})_RefErrs.hex4"
                        writ_hex4_file(ReadDataFile,ReadGnpuMemo)
                        input(f"Failed----Halting... Press ENTER")    
                    else:
                        print(f"H{hubs}_E{edge}_G{gnpu}_RawsData Check Pass,Continue...")     
        
        for gmsl in range(2):
            self.root_rimt_gnpu_ddrs( gmsl, root_radd, gnpu_addr, rows, cols,cols*64)
        
        rism_root_cols = int(  cols*64/16)
        rism_hubs_page = int(  cols*16/16)
        
        for hubs in range(1,4):
            rism_hubs_bias = int(hubs*rism_hubs_page)
            self.root_rsim_hubs_ddrs(rows, root_radd, rism_root_cols , rism_hubs_bias, rism_hubs_page, 0X0 , p=hubs)
        ###############################################################################################################

        ReadRIMTMemo = bytearray(rows*cols*64*2)
        ReadRIMTFile =  f"./test_read/ROOT_RIMT_FULL_DATA.hex4"
        self.pcie_rdma_root_ddrs(ReadRIMTMemo  ,root_radd  , 1  , cols*64*4 )
        
        GoldFileName = f"./stim_data/rimt/full_rimt_r{rows}_c{cols}.bin"    
        GoldDataMemo = malloc_file_memo(GoldFileName)

        if(ReadRIMTMemo!= GoldDataMemo):
            writ_hex4_file(ReadRIMTFile,ReadRIMTMemo)
            input(f"Failed----Halting... Press ENTER")    
        else:
            
            print(f"H{hubs}_E{edge}_G{gnpu}_RawsData Check Pass,Continue...")     
        
        print(f"ROOT BIST(RIMT) GNPU_DDR PASS!")     
########################################################################################################
########################################################################################################
########################################################################################################
#########################
# ###############################################################################
    def Agile_LLMB_Init(self, SKIP2805=0, SKIPEDGE=0):
        ##########################################################################################################    
        print(">>>>>>>>    STEP:1  AGILE RSTN    <<<<<<<<")
        self.root_cold_rstn_hubs(3,3)
        ##########################################################################################################
        extn_loop = 1
        for loop in range(extn_loop):
            print(f"----*----*----*----*----Start TUNE Loop::{loop:08d}@Total{extn_loop:08d}  ----*----*----*----*----  ")
            ##########################################################################################################
            print(">>>>>>>>    STEP:2  ROOT TRIM HUBS RXDI LANES            <<<<<<<<")
            tune_rxdi =1 
            while(tune_rxdi):
                tune_rxdi= self.root_tune_hubs_rxdi(PrintEn=1)
            print("\t\t\t\t\t~~~~~tune hubs RXDI lanes Done!")
            ##########################################################################################################
            print(">>>>>>>>    STEP:3  ROOT TRIM HUBS TXDO LANES            <<<<<<<<")
            tune_txdo =1 
            while(tune_txdo):
                tune_txdo=self.root_tune_hubs_txdo(PrintEn=1)
            print("\t\t\t\t\t~~~~~tune hubs TXDO lanes Done!")
        ##########################################################################################Test################
        print(">>>>>>>>    STEP:4  ROOT DownLoad HUBS Firmware          <<<<<<<<")
        self.root_boot_hubs_fmwr()
        ##########################################################################################################
        print(">>>>>>>>    STEP:5  ROOT Config HUBS ECOS Parameter      <<<<<<<<")
        self.root_cfig_hubs_ecos()
        ##########################################################################################################
        print(">>>>>>>>    STEP:6  ROOT lINK HUBS MGTH_SERDES           <<<<<<<<")
        self.root_link_hubs_sdes()

        extn_loop   = 1
        bist_loop   = 1
        for loop in range(extn_loop):
            print(f"################    Press Enter to Start BIST Loop::{loop:08d}@Total{extn_loop:08d}  ################")
            now = dt.now()
            print(f"----*----*----*----*----Start BIST Loop::{loop:08d}@Total{extn_loop:08d}  ----*----*----*----*----  ")
            print(f'----*----*----*----*----Start Time@{now.strftime("%Y-%m-%d %H:%M:%S")}')
            ##########################################################################################################
            print(">>>>>>>>    STEP:7  HOST BIST ROOT'S DDRS Memory         <<<<<<<<")
            #for i in range(root_loop):
            root_loop = bist_loop#10
            print(f">>>>>>>>    Start HOST BIST ROOT'S DDRS Memory Loop::{root_loop:08d}        <<<<<<<<")
            self.host_bist_root_ddrs(root_loop,256,4096)
            ##########################################################################################################
            print(">>>>>>>>    STEP:8  ROOT BIST HUBS'S DDRS Memory         <<<<<<<<")
            #os.system("rm ./test_read/*.hex4")
            hubs_loop = bist_loop#10  
            for i in range(hubs_loop):
                print(f">>1024>>>>>>    Start ROOT BIST HUBS'S DDRS Memory Loop::{i:08d}@Total{hubs_loop:08d}        <<<<<<<<")
                self.host_bist_hubs_ddrs(1,1,256,1024)
                self.host_bist_hubs_ddrs(2,1,256,1024)
                self.host_bist_hubs_ddrs(3,1,256,1024)
            ##########################################################################################################
            print(">>>>>>>>    STEP:9  ROOT BIST HUBS'S MGTH SERDES        <<<<<<<<")
            
            rism_loop = bist_loop#10
            for i in range(rism_loop):
                print(f">>>>>>>>    Start ROOT BIST HUBS'S MGTH SERDES Loop::{i:08d}@Total{rism_loop:08d}        <<<<<<<<")
                self.host_bist_mgth_ddrs(i,256,4096,1024)

            now = dt.now()
            print(f"----*----*----*----*----Finished BIST Loop::{loop:08d}@Total{extn_loop:08d}  ----*----*----  ")
            print(f'----*----*----*----*----Finished Time@{now.strftime("%Y-%m-%d %H:%M:%S")}')
        ########################################cube_cram##################################################################
        print(">>>>>>>>    STEP:10  ROOT DownLoad EDGE  BitFile     <<<<<<<<")
        self.root_boot_edge_fpga()
        self.ms_sleep(1000)
        ##########################################################################################################
        print(">>>>>>>>    STEP:11  ROOT INIT EDGE RESET            <<<<<<<<")   
        self.root_issu_edge_rstn(400000)
        ##########################################################################################################
        print(">>>>>>>>    STEP:12  ROOT TUNE EDGE RXDI DLYS        <<<<<<<<")   
        self.root_tune_edge_rxdi()
        ##########################################################################################################
        print(">>>>>>>>    STEP:12B  ROOT TUNE EDGE TXDO DLYS       <<<<<<<<")   
        self.root_tune_edge_txdo(128)
        ##########################################################################################################
        print(">>>>>>>>    STEP:14  ROOT BOOT EDGE'S GNPU           <<<<<<<<")   
        self.root_boot_2805_fmwr()
        ##########################################################################################################
        print(">>>>>>>>    STEP:15  ROOT BIST(XVCT) EDGE'S GNPU DDR <<<<<<<<")   
        xvct_loop = 1
        for i in range(xvct_loop):
            self.root_ovct_gnpu_bist(256,1024)
        ##########################################################################################################
        print(">>>>>>>>    STEP:16  ROOT BIST(OMTX_TILE) GNPU DDR <<<<<<<<")   
        omtx_loop = 0x1   
        for i in range(i):
            self.omtx_tile_gnpu_bist(omtx_loop,256,1024)
        ##########################################################################################################
        print(">>>>>>>>    STEP:16A  ROOT BIST(OMTX_RECT) GNPU DDR <<<<<<<<")   
        omtx_loop = 1   
        for i in range(omtx_loop):
            self.omtx_rect_gnpu_bist( 29,1024)
        ##########################################################################################################
        print(">>>>>>>>    STEP:17  ROOT BIST(RIMT) EDGE'S GNPU DDR <<<<<<<<")   
        rimt_loop = 1
        for i in range(rimt_loop):
            self.root_rimt_gnpu_bist(4,256)
        ##########################################################################################################
        print(">>>>>>>>    STEP:18  ROOT DOWNLOAD GNPU'S WEIGHT <<<<<<<<")   
        self.root_down_gnpu_wght()
        ##########################################################################################################
        print(">>>>>>>>    STEP:19  ROOT BOOT GNPU'S ECOS FirmWare  <<<<<<<<")   
        self.root_boot_gnpu_fmwr()
        
        print("Normally FINISHED!")
        
        





if __name__ == "__main__":
    Cards = Agile_Elaberate()
    Cards[0].Agile_LLMB_Init()
    