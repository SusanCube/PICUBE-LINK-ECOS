import os
import json


chip_num = 64
def add_weight_info(result, model_weight_folder, gnpu_index, base_adress, loop_index, adress_left, typename):

    dvp = "DVP0" if gnpu_index % 2 == 0 else "DVP1"
    port_index = 1 << (gnpu_index // 16)
    edge_index = 1 << ((gnpu_index % 16) // 2)
    portMsk = (port_index << 16) + edge_index

    if typename == 'loop':
        rel_path = f"loop/{loop_index}/weight{gnpu_index}.img"
    elif typename == 'head':
        rel_path = f"head/weight{gnpu_index}.img"
    elif typename == 'cossin':
        rel_path = f"cossin/weight.img"
    full_path = os.path.join(model_weight_folder, rel_path)
    if not os.path.exists(full_path):
        print(f"#error#, missing file {full_path}")
        return False
    weight_info = {"filepath": full_path, "data_address": int(base_adress + loop_index * adress_left), "dvp": dvp, "portMsk": hex(portMsk)}
    result["weight_list"].append(weight_info)
    result["total"] += 1
    return True


def generate_weight_json(model_weight_folder, json_data):
    result = {"weight_list": [], "total": 0}

    ##################
    model_num = len(json_data['model_weight'])
    valid = True
    for item in json_data['model_weight']:
        ############# loop
        loop_base_adress = json_data['model_weight'][item]['model_begin_position']
        one_loop_left = json_data['model_weight'][item]['one_loop_total']
        if item != 'Qwen3_4B':
            continue
        loop_num = json_data['model_weight'][item]['loop_num']
        for gnpu_index in range(chip_num):
            for loop_index in range(loop_num):
                valid = add_weight_info(result, model_weight_folder, gnpu_index, loop_base_adress, loop_index, one_loop_left, typename="loop")
        ############### lm_head
        head_base_adress = int(loop_base_adress + loop_num * one_loop_left)
        one_head_total = json_data['model_weight']['Qwen3_4B']['one_head_total']
        for gnpu_index in range(chip_num):
            loop_index = 0
            valid = add_weight_info(result, model_weight_folder, gnpu_index, head_base_adress, loop_index, one_head_total, typename="head")
    #####cos_sin
    cossin_base_adress = json_data['cossin']['cossin_begin_position']
    for gnpu_index in range(chip_num):
        loop_index = 0
        valid = add_weight_info(result, model_weight_folder, gnpu_index, cossin_base_adress, loop_index, one_head_total, typename="cossin")
    return result


if __name__ == "__main__":
    chip_num = 64
    file_path = "golden/data/position.json"
    folder = "/home/home1/jinyu/weight_data/spilt_weight/qwen/Qwen3-4B/Qwen3-4B-Recombination-chip_64-20260108"
    with open(file_path, 'r', encoding='utf-8') as f:
        json_data = json.load(f)
    weight_data = generate_weight_json(folder, json_data)
    print(f"{weight_data['total']}")
    with open("golden/data/weight_info.json", "w", encoding="utf-8") as f:
        json.dump(weight_data, f, ensure_ascii=False, indent=2)
