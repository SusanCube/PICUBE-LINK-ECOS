from config import *
from pcie_base_task import *
from datetime import datetime as dt

class ROOT_TUNE_LINK(PCIe_Base):

    def __init__(self):
        pass
############################################################################################    
    def root_link_hubs_sdes(self):
        self.pcie_cfig_cmnd(0x0f0000,0x05,0 ,0 ,0,0,0,0,0,0,0,0 , 0x15, 0, 0, 0)
        self.pcie_issu_cmnd(LLMB_OCFG_CMND)
        self.ms_sleep(100)
        self.pcie_cfig_cmnd(0x0f0000,0x05,0 ,0 ,0,0,0,0,0,0,0,0 , 0x00, 0, 0, 0)
        self.pcie_issu_cmnd(LLMB_OCFG_CMND)
        self.ms_sleep(100)
        #self.pcie_icfg_mgth(0xc)            
        
        self.pcie_cfig_cmnd(0x0f0000,0x05,0 ,0 ,0,0,0,0,0,0,0,0 , 0, 0, 0, 0)
        while 1:
            self.us_sleep(100)
            self.pcie_issu_cmnd(LLMB_ICFG_CMND)
            rgs0 = self.PCIe_ReadCtrl(TPGS0_ACKS_DATA0, 1)
            rgs1 = self.PCIe_ReadCtrl(TPGS1_ACKS_DATA0, 1)
            rgs2 = self.PCIe_ReadCtrl(TPGS2_ACKS_DATA0, 1)
            rgs3 = self.PCIe_ReadCtrl(TPGS3_ACKS_DATA0, 1)
            
            if rgs0[0] == 0x3f0000 and rgs1[0] == 0x2b0000 and rgs2[0] == 0x2b0000 and rgs3[0] == 0x2b0000:
                print("ROOT Link MGTH_SERDES   Successfully!!!")
                break
############################################################################################
    def analyz_tune_stat(self,data,port,PrintEn=0):
        segments = [] 
        n = len(data)   
        i = 0   
        while i < n:
            if(data[i]) == 1:
                start = i 
                
                while i < n and data[i]  == 1:
                    i+=1
                
                end = i -1 

                valid = end - start + 1
                cents = int((start + end) /2 )
                segments.append((start,end,valid,cents))
            else:
                i+=1
        if PrintEn:
            print(f"Analyze Tune_Dlys_Result::Channel_{port}-->>{segments}")
        return  segments
############################################################################################    
    def choice_tune_dlys(self, data,port,PrintEn=0):
        if not data:
            return 0,0,0
        
        cent_taps   =   data[0][3]
        maxi_leng   =   data[0][2]

        for i,(start,end,leng,cents) in enumerate(data):
            if leng > maxi_leng :
                maxi_leng = leng
                cent_taps = cents

        if(maxi_leng<200):
            print(f"UI Windows very Narrow!{cents}@SP{start}::EP{end}")
        else:
            if PrintEn:
                print(f"Choice Channel_{port} Center_DLYS_Taps~{cent_taps},Valid_UI_Windows~{maxi_leng*6}ps")
        
        return cent_taps    
############################################################################################    
    def adjust_root_rdly(self, taps,PrintEn=0):
        self.PCIe_WriteCtrl(0x51, [taps])  #0x36
        self.PCIe_WriteCtrl(0x52, [taps])  #0x36
        self.PCIe_WriteCtrl(0x53, [taps])  #0x36
        
        self.ms_sleep(10)
        
        res1 = self.PCIe_ReadCtrl(0x51)
        res2 = self.PCIe_ReadCtrl(0x52)
        res3 = self.PCIe_ReadCtrl(0x53)

        if PrintEn:
            print(f"TUNE_HUBS_RXDI_Status::{taps}\t\tHUB1::{hex(res1[0])}\t\tHUB2::{hex(res2[0])}\t\tHUB3::{hex(res3[0])}")

        rsp1 =int((res1[0] & 0xffff0000) == 0x83ff0000) 
        rsp2 =int((res2[0] & 0xffff0000) == 0x83ff0000) 
        rsp3 =int((res3[0] & 0xffff0000) == 0x83ff0000) 
        
        return  rsp1,rsp2,rsp3
############################################################################################    
    def config_root_rdly(self, tap1, tap2, tap3,PrintEn=0):
        self.PCIe_WriteCtrl(0x51, [tap1])  #0x36
        self.PCIe_WriteCtrl(0x52, [tap2])  #0x36
        self.PCIe_WriteCtrl(0x53, [tap3])  #0x36
        self.ms_sleep(10)
        
        rsp1 = self.PCIe_ReadCtrl(0x51)
        rsp2 = self.PCIe_ReadCtrl(0x52)
        rsp3 = self.PCIe_ReadCtrl(0x53)
        
        if PrintEn:
            print(f"Config_HUBS_1_RXDI_TAPS_Status::\t{hex(rsp1[0])}    @RXDI_DLYS_TAPS({hex(tap1)})")        
            print(f"Config_HUBS_2_RXDI_TAPS_Status::\t{hex(rsp2[0])}    @RXDI_DLYS_TAPS({hex(tap2)})")        
            print(f"Config_HUBS_3_RXDI_TAPS_Status::\t{hex(rsp3[0])}    @RXDI_DLYS_TAPS({hex(tap3)})")        
############################################################################################
    def root_tune_hubs_rxdi(self,PrintEn=0):
        if PrintEn:
            print("Disable ROOT_TUNE_MODE ")
        self.PCIe_WriteCtrl(TPGM_TUNE_MODE, [0x00000])  #0x36
        if PrintEn:
            print("Enable  ROOT_TUNE_HUBS ")
        self.PCIe_WriteCtrl(0x0, [0x000e0000])  #0x0  HUBS_ENABLE
        if PrintEn:
            print("Sets    ROOT_TUNE_MODE::RXDI ")
        self.PCIe_WriteCtrl(TPGM_TUNE_MODE, [0x00001])  #0x36
        
        lane_rxd1_tune_good =   [0] *512
        lane_rxd2_tune_good =   [0] *512
        lane_rxd3_tune_good =   [0] *512
        
        for i in range(512):
            lane_rxd1_tune_good[i],lane_rxd2_tune_good[i],lane_rxd3_tune_good[i]=self.adjust_root_rdly(i,PrintEn)
        
        seg1=self.analyz_tune_stat(lane_rxd1_tune_good,1,PrintEn)
        seg2=self.analyz_tune_stat(lane_rxd2_tune_good,2,PrintEn)
        seg3=self.analyz_tune_stat(lane_rxd3_tune_good,3,PrintEn)

        if (seg1 ==[] ) or (seg2 ==[] ) or (seg3 ==[] ) :
            print("RXDI PORT TUNE FAILED!!!!")
            return 1
        
        tap1 = self.choice_tune_dlys(seg1,1,PrintEn)
        tap2 = self.choice_tune_dlys(seg2,2,PrintEn)
        tap3 = self.choice_tune_dlys(seg3,3,PrintEn)
        
        self.config_root_rdly(tap1,tap2,tap3,PrintEn)
        print("Tune ROOT_RXDI_DLYS DONE")
        return 0
############################################################################################
    def adjust_root_tdly(self,taps,PrintEn):
        self.PCIe_WriteCtrl(0x41, [taps])  
        self.PCIe_WriteCtrl(0x42, [taps])  
        self.PCIe_WriteCtrl(0x43, [taps])  
        
        self.ms_sleep(10)
        self.PCIe_WriteCtrl(TPGM_TUNE_MODE, [0x02])  #0x36
        self.ms_sleep(10)
        self.PCIe_WriteCtrl(TPGM_TUNE_MODE, [0x00])  #0x36

        ack1 = self.PCIe_ReadCtrl(0x18)
        ack2 = self.PCIe_ReadCtrl(0x20)
        ack3 = self.PCIe_ReadCtrl(0x28)
        
        res1 =  int(ack1[0] == 0x5458444f)
        res2 =  int(ack2[0] == 0x5458444f)
        res3 =  int(ack3[0] == 0x5458444f)
 
        ol1 = "-o-" if(ack1[0] == 0x5458444f) else "-X-"
        ol2 = "-o-" if(ack2[0] == 0x5458444f) else "-X-"
        ol3 = "-o-" if(ack3[0] == 0x5458444f) else "-X-"
        
        if PrintEn:
            print(f"Tune_HUBS_TXDO_Status::{taps}\t\tHUB1::{ol1}\t\tHUB2::{ol2}\t\tHUB3::{ol3}")    
 
        return res1,res2,res3
############################################################################################
    def config_root_tdly(self, tap1,tap2,tap3,PrintEn):
        self.PCIe_WriteCtrl(0x38, [0X00])  #CLEAR ACKS MEMO
            
        self.PCIe_WriteCtrl(0x41, [tap1])  #0x36
        self.PCIe_WriteCtrl(0x42, [tap2])  #0x36
        self.PCIe_WriteCtrl(0x43, [tap3])  #0x36
        
        self.ms_sleep(10)
        self.PCIe_WriteCtrl(TPGM_TUNE_MODE, [0x02])  #0x36
        self.ms_sleep(10)
        self.PCIe_WriteCtrl(TPGM_TUNE_MODE, [0x00])  #0x36

        ack1 = self.PCIe_ReadCtrl(0x18)
        ack2 = self.PCIe_ReadCtrl(0x20)
        ack3 = self.PCIe_ReadCtrl(0x28)
        
        if PrintEn:
            print(f"Config_HUB1_TXDO_TAPS_STATUS::\t{hex(ack1[0])}    @TXDO_DLYS_TAPS::({hex(tap1)})")        
            print(f"Config_HUB2_TXDO_TAPS_STATUS::\t{hex(ack2[0])}    @TXDO_DLYS_TAPS::({hex(tap2)})")        
            print(f"Config_HUB3_TXDO_TAPS_STATUS::\t{hex(ack3[0])}    @TXDO_DLYS_TAPS::({hex(tap3)})")        
############################################################################################
    def root_tune_hubs_txdo(self,PrintEn):
        if PrintEn:
            print("Disable ROOT_TUNE_MODE ")
        self.PCIe_WriteCtrl(TPGM_TUNE_MODE, [0x00000])  #0x36
        if PrintEn:    
            print("Enable  ROOT_TUNE_HUBS::HUBS1&2&3 ")
        self.PCIe_WriteCtrl(0x0, [0x000e0000])  #0x0  HUBS_ENABLE
        if PrintEn:
            print("Force TPGM_HUBS LINK_ENABLE")

        lane_txd1_tune_good =   [0] *512
        lane_txd2_tune_good =   [0] *512
        lane_txd3_tune_good =   [0] *512
            
        for i in range(512):    
            self.PCIe_WriteCtrl(0x38, [0X00])  #CLEAR ACKS MEMO
            self.ms_sleep(10)
            lane_txd1_tune_good[i],lane_txd2_tune_good[i],lane_txd3_tune_good[i] = self.adjust_root_tdly(i,PrintEn)

        seg1=self.analyz_tune_stat(lane_txd1_tune_good,1,PrintEn)
        seg2=self.analyz_tune_stat(lane_txd2_tune_good,2,PrintEn)
        seg3=self.analyz_tune_stat(lane_txd3_tune_good,3,PrintEn)

        if (seg1 ==[] ) or (seg2 ==[] ) or (seg3 ==[] ) :
            if PrintEn:
                print("TXDO PORT TUNE FAILED!!!!")
            
            return 1
        

        tap1 = self.choice_tune_dlys(seg1,1,PrintEn)
        tap2 = self.choice_tune_dlys(seg2,2,PrintEn)
        tap3 = self.choice_tune_dlys(seg3,3,PrintEn)

        self.config_root_tdly(tap1,tap2,tap3,PrintEn)
        
        if PrintEn:
            print("Tune ROOT_TXDO_DLYS DONE")
        return 0
############################################################################################
    def hubs_trim_edge_cmnd(self,HUBS,EDGE,CMND,DLYS):
        PORT = (HUBS <<16)|EDGE
        if CMND =="RXDI_DLYS" :
            MISC = 0X8 
            PARA = DLYS
        elif CMND =="RXDI_STAT" :   
            MISC = 0X9
            PARA = 0
        elif CMND =="TXDO_DLYS" :   
            MISC = 0XA
            PARA = DLYS
        elif CMND =="TXDO_TAPS" :   
            MISC = 0XB
            PARA = 0
        elif CMND =="RXDI_ENAB" :   
            MISC = 0XD
            PARA = 0
        else:
            MISC = 0XC    
            PARA = 0
        self.pcie_cfig_cmnd(PORT,0,MISC ,0 ,0,0,0,0,0,0,0,0 , PARA, 0, 0, 0)
        self.pcie_issu_cmnd(LLMB_TRIM_CMND)
############################################################################################
    def show_root_acks_stat(self,data):
        now = dt.now()
        print(f'@{now.strftime("%Y-%m-%d %H:%M:%S:%f")}')

        for i in range(32):
            print(f"{data[i]:08x} ",end="")
        print("\n")    
############################################################################################
    def init_trim_acks_zero(self):
        self.PCIe_WriteCtrl(0x38, [0X00])  #CLEAR ACKS MEMO
        self.ms_sleep(1)
        
        INPUT = c_uint32 * 32
        data = INPUT()
        self.pcie_reg_read(0x10*4,data,32)

        for i in range(32):
            if data[i] != 0:
                return 0 
            
        return 1 
############################################################################################
    def hubs_trim_acks_stat(self,txrx,leng):
        #if txrx == "RXDI":
        #    self.pcie_cfig_cmnd(0xf0000,0,0x9 ,0 ,0,0,0,0,0,0,0,0 , 0, 0, 0, 0)
        #else:
        #    self.pcie_cfig_cmnd(0xf0000,0,0xb ,0 ,0,0,0,0,0,0,0,0 , 0, 0, 0, 0)    

        self.pcie_cfig_cmnd(0xf0000,0,0x9 ,0 ,0,0,0,0,0,0,0,0 , 0, 0, 0, 0)
        self.pcie_issu_cmnd(LLMB_ICFG_CMND)            

        INPUT = c_uint32 * 32
        data = INPUT()
        self.pcie_reg_read(0x10*4,data,leng)
        
        return data
############################################################################################
    def root_issu_edge_rstn(self,time):
        self.pcie_cfig_cmnd(0xf00ff,0,0x6 ,0, 0,0,0,0, 0,0,0,0 ,time, 0, 0, 0)
        self.pcie_issu_cmnd(LLMB_OCFG_CMND) 
        self.ms_sleep(1000)           
############################################################################################
#    def hubs_data_rxdi_enab(self,enab):
#        self.pcie_cfig_cmnd(0xf00ff,0,0x5 ,0, 0,0,0,0, 0,0,0,0 ,enab, 0, 0, 0)
#        self.pcie_issu_cmnd(LLMB_OCFG_CMND) 
############################################################################################
    def root_tune_edge_rxen(self):
        print("ROOT Enable EDGE_RXDI_Channel... ")
        self.hubs_trim_edge_cmnd(0X0F,0XFF,"RXDI_ENAB",0)
        self.ms_sleep(1)
############################################################################################
    def root_tune_edge_rxdi(self):
        print("HUBS_TUNE_EDGE_RXDI ... ")
        
        tune_edge_lane_acks =  [[0] * 32 for _ in range(512)]
        tune_edge_lane_stat =   [0] * 512

        for i in range(512):
            tune_edge_stat_accm =    0
            #self.PCIe_WriteCtrl(0x38, [0X00])  #CLEAR ACKS MEMO
            #self.ms_sleep(1)
            
            clrs_acks = self.init_trim_acks_zero()
            if clrs_acks == 0 :
                print("TRIM ACKS_MEMO Failed!")
            #print(f"TUNE_EDGE_RXDI::Set DELAYS@DELAYS={i:04d}\t")#,end="")
            self.hubs_trim_edge_cmnd(0X0F,0XFF,"RXDI_DLYS",i)
            self.ms_sleep(10)
            print(f"TUNE_EDGE_RXDI_DLYS@{i:04d}\t",end="")
            self.hubs_trim_edge_cmnd(0X0F,0XFF,"RXDI_STAT",0)
            self.ms_sleep(2)
            tune_edge_lane_acks[i] = self.hubs_trim_acks_stat("RXDI",32) 

            for j in range(32):
                if j==0 :
                    print(f"  <HUB0>:",end="")
                elif j==8 :    
                    print(f"  <HUB1>:",end="")
                elif j==16 :    
                    print(f"  <HUB2>:",end="")
                elif j==24 :    
                    print(f"  <HUB3>:",end="")
                
                msg = (tune_edge_lane_acks[i][j] & 0xffff0000 == 0x03ff0000)
                if msg:
                    #print(f"-{msg:01x}-",end="")
                    print(f"--",end="")
                    tune_edge_stat_accm +=    1
                else:
                    print(f"-X",end="")    
            
            tune_edge_lane_stat[i] =   1 if(tune_edge_stat_accm==32) else 0
            if(tune_edge_lane_stat[i]):
                print(f"\t EDGE_RXDI_LANE_EYES GOOD ")
            else:
                print(f"\t EDGE_RXDI_LANE_EYES MISS ")

        edge_tune_segs =self.analyz_tune_stat(tune_edge_lane_stat,32,PrintEn=1)   
        edge_tune_taps =self.choice_tune_dlys(edge_tune_segs,32,PrintEn=1)

########FINAL CONFIG RXDI_DLYS
        self.PCIe_WriteCtrl(0x38, [0X00])  #CLEAR ACKS MEMO

        print(f"Config EDGE Channels*32 RXDI_LANE_DLYS:{edge_tune_taps}")
        self.hubs_trim_edge_cmnd(0X0F,0XFF,"RXDI_DLYS",edge_tune_taps)
        self.ms_sleep(10)
        self.hubs_trim_edge_cmnd(0X0F,0XFF,"RXDI_STAT",0)
        self.ms_sleep(2)
        config_edge_rxd1_acks = self.hubs_trim_acks_stat("RXDI",32)         
      
        print(f"Confirm EDGE Channels*32 TUNE_RXDI_DLYS@{edge_tune_taps}::\n")
        print("    ----    ----edge0---edge1---edge2---edge3---edge4---edge5---edge6---edge7\n")
        result = 1    
        for m in range(4):
            print(f"  <HUB{m}>:",end="")
            for n in range(8):
                msg = (config_edge_rxd1_acks[m*8+n] & 0xffff0000 == 0x03ff0000)
                if msg:
                   print(f"\tgood",end="")
                else:
                   print(f"\tFAIL",end="")    
                   result = 0
            print("\n")
        
        print("    ----    ----    ----    ----    ----    ----    ----    ----    ----")
        self.hubs_trim_edge_cmnd(0X0F,0XFF,"TUNE_DISABLE",0)
        if(result):
            print(f"\t EDGE_RXDI_LANE Tune Successfully!!! ")
        else:
            print(f"\t EDGE_RXDI_LANE Tune Failed!!! ")
        ############################################################################################
        print("****    ****    ROOT Enable EDGE_RXDI_Channel    ****    ****")
        self.hubs_trim_edge_cmnd(0X0F,0XFF,"RXDI_ENAB",0)
        self.ms_sleep(1)
    
############################################################################################
#        self.hubs_data_rxdi_enab(0xff)
    def root_tune_edge_txdo(self,loop):
        print("****    ****    ROOT Enable FULL_EDGE_PORT     ****    **** ")
        self.pcie_cfig_cmnd(0xf00ff,0,0x5 ,0, 0,0,0,0, 0,0,0,0 ,0xff, 0, 0, 0)
        self.pcie_issu_cmnd(LLMB_OCFG_CMND) 

        tune_edge_lane_acks =  [0] * 32 

        for i in range(loop):
            bist_edge_txdo_accm =    0
            
            self.PCIe_WriteCtrl(0x38, [0X00])  #CLEAR ACKS MEMO
            print(f"BIST_EDGE_TXDO::LOOP@{i:03d}\t",end="")
            #self.ms_sleep(1)
            self.hubs_trim_edge_cmnd(0X0F,0XFF,"TXDO_DLYS",0)
            self.ms_sleep(10)
            self.hubs_trim_edge_cmnd(0X0F,0XFF,"TUNE_DISABLE",0)
            self.ms_sleep(2)
            tune_edge_lane_acks = self.hubs_trim_acks_stat("RXDI",32) #           self.show_root_acks_stat(tune_edge_lane_acks[i]) 
           
            for j in range(32):
                if j==0 :
                    print(f"  <HUB0>:",end="")
                elif j==8 :    
                    print(f"  <HUB1>:",end="")
                elif j==16 :    
                    print(f"  <HUB2>:",end="")
                elif j==24 :    
                    print(f"  <HUB3>:",end="")
            
                msg = (tune_edge_lane_acks[j] == 0x41434b53)
                if msg:
                    print(f"-o-",end="")
                    bist_edge_txdo_accm += 1
                else:
                    print(f"-X-",end="")    
            
            if(bist_edge_txdo_accm == 32):
                print(f"\t BIST_EDGE_TXDO_LINK PASS ")
            else:
                print(f"\t BIST_EDGE_TXDO_LINK FAIL ")    

        
