import os
import json
from datetime import datetime as  dt
from config import *
from config_init import *

from base_core_util import *
from pcie_base_task import *
from pcie_llmb_task import *
from pcie_link_util import *
from generate_down_weight_config_json import *

class GNPU_MISC_TASK(PCIe_LLMB):
    def __init__(self, cid):
        PCIe_LLMB.__init__(self, cid)
#####################################################################################    
    def ispm_pack_gnpu_code(self,code):
        b=code
        addr = str(codeAddr)
        codeSize = len(code)
        size = str(codeSize)
        lead = "W " + addr + " " + size + "\r"

        lead = [ord(c) for c in lead]
        tail = size + "\r"

        tail = [ord(c) for c in tail]
        full_code = lead + code + tail
        full_code = util_alignment(full_code, 4, 0x1b) ## PACK_TO_1WORD, 1b = ESC
        if PACK_TO_8WORD == 1:
            leng = len(full_code)
            left = leng % 8
            if left > 0:
                full_code += [0x1b1b1b1b]*(8-left)
        return full_code
#####################################################################################
    def ispm_link_2805_init(self):
        self.tpem_ocfg_tpes(TPES_SYSC_STAT, 0x00)
        stat=self.tpem_icfg_tpes(TPES_SYSC_STAT)
        self.tpem_ocfg_tpes(TPES_SYSC_STAT, 0xff)
        stat=self.tpem_icfg_tpes(TPES_SYSC_STAT)
        stat=self.tpem_icfg_tpes(TPES_BAUD_RATE)
        stat=self.tpem_icfg_tpes(TPES_UART_CTRL)
        self.ms_sleep(100) 
#####################################################################################
    def ispm_down_2805_code(self,code):
        self.tpes_enab_ispm()

        print("Reset ALL GNPU\n")
        self.pcie_cfig_cmnd(0xf00ff, 0, 3, 0)
        self.pcie_issu_cmnd(LLMB_ASET_CMND)
        for i in range(6):
            print(".",end="")
            
        print("Reset ALL GNPU Done!")
        self.tpem_icfg_tpes(TPES_SYSC_STAT)
        self.root_quiz_2805_stat(TPES_SYSC_STAT, 0xff01)  # wait ISP OK

        self.pcie_2805_load(code)
        self.tpem_icfg_tpes(TPES_SYSC_STAT)

        print(f"LLMB_BOOT_CMND => GNPU")
        self.pcie_cfig_cmnd(0xf00ff, 0, 3, 0)
        self.pcie_issu_cmnd(LLMB_BOOT_CMND)
        self.tpem_icfg_tpes(TPES_SYSC_STAT)
#####################################################################################
    def ispm_boot_2805_stat(self, piles):
        print(f"=================================================")
        DxScan = TPES_CUBE_DDRS_BEOK
        DxInit = TPES_CUBE_DDRI_BEOK
        D0Fail = TPES_CUBE_DDR0_FAIL
        D1Fail = TPES_CUBE_DDR1_FAIL
        fail = 0
        scan = 1
        for i,p in enumerate(piles):
            for j,e in enumerate(p):
                if (e & DxInit) != DxInit or (e & D0Fail) == D0Fail:
                    fail = 1
                    print(f"p{i+P0}e{j+E0} DDR0 Fail.")
                if (e & DxInit) != DxInit or (e & D1Fail) == D1Fail:
                    fail = 1
                    print(f"p{i+P0}e{j+E0} DDR1 Fail.")
                if (e & DxScan) != DxScan:
                    print(f"p{i+P0}e{j+E0} DDRS' Driver Mismatch.")
                    scan = 0
        if fail == 0:
            print(f"DDR TRIM PASS.")
        else:
            print(f"DDR TRIM FAIL.")
        if scan == 1:
            print(f"ALL SCAN PASS.")
        print(f"=================================================\n\n")
        return fail
#####################################################################################
    def root_boot_2805_fmwr(self):
        self.tpem_ocfg_tpes(BaudAddr,217)# 271)#346)
        code_raws_data = util_read_from_img(CUBE_ECOS_FILE)
        code_pack_data = self.ispm_pack_gnpu_code(code_raws_data)          
    #    code_pack_size = int(len(code_pack_data)) * 4        
        
        self.ispm_link_2805_init()
        retry = 0
        passFlag = 0
        while passFlag <= 0 and retry < 20:
                self.ispm_down_2805_code(code_pack_data)
                passFlag,piles = self.root_quiz_2805_stat(TPES_SYSC_STAT, 0xff3f)#, timeout=20, stopVal=0x80)  # DDR SCAN
                retry = retry + 1
                self.ispm_boot_2805_stat(piles)
                self.ms_sleep(30)
        
        if passFlag == 1:
            print("GNPU BOOT SUCEESSFUlLY!")
        else :
            print("GNPU BOOT FAILED!")    
#####################################################################################
    def root_read_gnpu_fmwr(self,hubs,edge,gnpu,sadd,rows,cols):
        GnpuMemoRead = bytearray(rows*cols*2)
        self.root_ivct_gnpu_ddrs(hubs,edge,gnpu,0x00200000,sadd,rows,cols)
        self.pcie_rdma_root_ddrs(GnpuMemoRead  ,0x00200000, rows  , cols  )
        return  GnpuMemoRead
#####################################################################################
    def root_read_gnpu_wght(self,portMsk,gnpu,sadd,rows,cols):
        GnpuMemoRead = bytearray(rows*cols*2)
        self.pcie_cfig_cmnd(portMsk, 0, 0, gnpu+6, 0x200000, sadd, rows, cols, rows, cols, 0, 0, 0, 0, 0, 0X110000F0)
        self.pcie_issu_cmnd(LLMB_IVCT_CMND)     
        self.pcie_rdma_root_ddrs(GnpuMemoRead  ,0x200000  , rows  , cols  )
        return  GnpuMemoRead
#####################################################################################
    def root_boot_gnpu_fmwr(self):    
        print("\t\t*Set GNPU's Frequence::500Mhz")
        self.pcie_cfig_cmnd(0xf00ff, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 320, 3, 0, 0x15000000)
        self.pcie_issu_cmnd(LLMB_OCFG_CMND)
        self.ms_sleep(50)

        print(f"\t\t*DownLoad GNPU LLMB_ECOS firmware::{GNPU_ECOS_FILE}")
        GNPUCodeMemo = malloc_file_memo(GNPU_ECOS_FILE)
        GNPUCodeSize = int(len(GNPUCodeMemo) /2)

        cols_tail   =    int (GNPUCodeSize % 1024)
        if cols_tail == 0 :
            GNPUCodeRows = int(GNPUCodeSize / 1024)
        else: 
            GNPUCodeRows = int(GNPUCodeSize // 1024 + 1)
            cols_dmmy = 1024 -cols_tail 
            cols_dmmy *= 2
            
            GNPUCodeMemo.extend([0]*cols_dmmy)

        root_wadd = 0x10000
        self.pcie_wdma_root_ddrs(GNPUCodeMemo   ,root_wadd  ,           GNPUCodeRows  , 1024 )
        self.root_ovct_gnpu_code(0xf,0xff,2     ,root_wadd  ,   0x0   , GNPUCodeRows  , 1024 )    
         
        print("\t\t*GNPU LLMB_ECOS firmware DownLoad Done!")

        if 1:
            WritDataFile =  f"./test_read/GNPU_FIRMWARE_Golden.hex4"
            writ_hex4_file(WritDataFile,GNPUCodeMemo)
            for i in range(4):
                for j in range(8):
                    for k in range(2):
                        GnpuCodeRead = self.root_read_gnpu_fmwr(i,j,k,0x1000,GNPUCodeRows,1024)
                        if(GnpuCodeRead!= GNPUCodeMemo):
                            ReadDataFile =  f"./test_read/GNPU_FIRMWARE_HUBS({i:01d})_EDGE({j:02d})_GNPU({k:01d}).hex4"
                            writ_hex4_file(ReadDataFile,GnpuCodeRead)
                            input(f"GNPU_FIRMWARE_H{i}_E{j}_G{k}_Compare Failed----Halting... Press ENTER")    
                        else:
                            print(f"Check GNPU::(H{i}_E{j}_G{k})FIRMWARE Pass,Continue...")    


        GNPUCodeSize    =   int(GNPUCodeRows * 2048)

        print("\t\t*Move  GNPU firmware from GNPU'S DDR to GNPU'S CODERAM")
        self.pcie_cfig_cmnd(0xf00ff, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0,   1, 3, GNPUCodeSize,   0x15000001)
        self.pcie_issu_cmnd(LLMB_OCFG_CMND)

        print("\t\t*BOOT  GNPU firmware in GNPU'S CODERAM")
        self.pcie_cfig_cmnd(0xf00ff, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0,   1, 3, 0,              0x15000002)
        self.pcie_issu_cmnd(LLMB_OCFG_CMND)
        
        self.ms_sleep(50)

        
        print("\t\t*Assign Unique ID to each GNPU")
        for i in range(4):
            for j in range(8):
                edge = i * 8 + j
                
                portMsk = ((2**i) << 16) | (2**j)
                self.pcie_cfig_cmnd(portMsk, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 2*edge, 0, 0,    0x15001800)
                self.pcie_issu_cmnd(LLMB_OCFG_CMND)
                
#####################################################################################
    def root_down_gnpu_wght(self):
        with open(WGHT_POSI, 'r', encoding='utf-8') as f:
            json_data = json.load(f)
        
        weight_json = generate_weight_json(WGHT_PATH, json_data)

        now = dt.now()
        this_time = now.strftime("%Y-%m-%d %H:%M:%S")
        print("Begin downlaod weigth:", this_time)

        indx = 0 
        for item in weight_json['weight_list']:
            WghtFile = item['filepath']
            WghtAddr = item['data_address']

            dvp = item['dvp']
            if type(dvp) == str:
                if dvp == 'DVP0':
                    dvp = DVP0
                    gmsl = 0
                if dvp == 'DVP1':
                    dvp = DVP1
                    gmsl = 1

            portMsk = item['portMsk']
            if type(portMsk) == str:
                portMsk = eval(portMsk)

            GNPUWghtSize = int(os.path.getsize(WghtFile) /2)
            GNPUWghtRows = int(GNPUWghtSize / 1024)
    

            self.pcie_wdma_ddrs(WghtFile, 0x10000, GNPUWghtRows  , 1024 )
            self.root_ovct_gnpu_wght(portMsk,dvp ,0x10000,  WghtAddr  ,  GNPUWghtRows  , 1024 )    
            print(f"WghtFile::{WghtFile}_WghtAddr::{WghtAddr:08x}_FileSize::{GNPUWghtSize} DownLoad Done ")
            
            if 0:
                indx +=1
                GNPUWghtGood = malloc_file_memo(WghtFile)
                WritDataFile =  f"./test_read/FILE_{indx}_Golden.hex4"
                writ_hex4_file(WritDataFile,GNPUWghtGood)
                
                GnpuWghtRead = self.root_read_gnpu_wght(portMsk,gmsl,WghtAddr,GNPUWghtRows,1024)

                if(GnpuWghtRead!= GNPUWghtGood):
                    ReadDataFile =  f"./test_read/FILE_{indx}_failed.hex4"
                    writ_hex4_file(ReadDataFile,GnpuWghtRead)
                    input(f"GNPU_WGHT_FILE_{indx}_Compare Failed----Halting... Press ENTER")    
                else:
                    print(f"GNPU_WGHT_FILE_{indx}_Data@ADDR::{WghtAddr} Compare Pass,Continue...")    

        now = dt.now()
        this_time = now.strftime("%Y-%m-%d %H:%M:%S")
        print("finish downlaod weigth:", this_time)
