import sys
import datetime
from pcie_base_task import *
from base_core_util import *

class LINK_UTIL(PCIe_Base):

    def __init__(self):
        pass
##################################################################################################
    def root_cfig_hubs_ecos(self):
        for p in range(4):
            portMsk = (2**p)<<16
            self.tpgm_ocfg_ecos(portMsk, 0x12345678, self.Card_ID, 0x33333333, p)
        self.tpgm_icfg_ecos(0XF0000)
        passFlag = 1
        for p in range(4):
            data = self.PCIe_ReadCtrl(0x10 + p*8, 4)
            if data[0] != 0x12345678:
                passFlag = 0
            if data[1] != self.Card_ID:
                passFlag = 0
            if data[2] != 0x33333333:
                passFlag = 0
            if data[3] != p:
                passFlag = 0
        if passFlag == 1:
            return PASS_FLAG
        else:
            return ERROR_TPGM_LINK_FAIL
##################################################################################################
    def root_quiz_2805_stat(self, addr, expect):
        pass_flag = 0
        quiz_loop = 0
        while pass_flag <= 0:
            if quiz_loop == 0X20 :
                break

            self.ms_sleep(1000)
            quiz = self.tpem_icfg_tpes(addr)
            quiz_loop +=1
            print(f"quiz_gnpu_stat_loop {quiz_loop} :[",end="")

            pass_cnts  = 0
            for hubs in range(4) :
                print("[",end="")
                for edge in range(8):
                    stat = quiz[hubs][edge]
                    print(f" {stat:04x},",end="") 
                    if stat == expect:
                        pass_cnts +=1
                print("]",end="")
                

            print(f" ]\n") 
            pass_flag = 1 if pass_cnts == 0x20 else 0
        return pass_flag ,quiz
##################################################################################################
    def agile_lx9_ocfg(self, port, edge, addr, data):
        portMsk = ((2**port)<<16) | (2**edge)
        real_addr = 0xc0000000 + addr * 4
        self.PCIe_WriteCtrl(DEST_PORT_ENAB, [portMsk])
        self.PCIe_WriteCtrl(TPGS_DEST_MARK, [0x00000])
        self.PCIe_WriteCtrl(TPES_DEST_MARK, [0x00002])
        self.PCIe_WriteCtrl(EDGE_AUXI_WRD0, [real_addr])
        self.PCIe_WriteCtrl(EDGE_AUXI_WRD1, [data])
        self.pcie_issu_cmnd(0x12)
##################################################################################################
    def agile_lx9_icfg(self, port, edge, addr):
        portMsk = ((2**port)<<16) | (2**edge)
        real_addr = 0xc0000000 + addr * 4
        self.PCIe_WriteCtrl(DEST_PORT_ENAB, [portMsk])
        self.PCIe_WriteCtrl(TPGS_DEST_MARK, [0x00000])
        self.PCIe_WriteCtrl(TPES_DEST_MARK, [0x00002])
        self.PCIe_WriteCtrl(EDGE_AUXI_WRD0, [real_addr])
        self.pcie_issu_cmnd(0x11)
##################################################################################################
     