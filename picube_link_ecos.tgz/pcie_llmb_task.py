import sys
import time
from config import *
from pcie_base_task import *
#from pcie_link_util import *
from base_core_util import *

class PCIe_LLMB(PCIe_Base):

    def __init__(self, cid):
        PCIe_Base.__init__(self, cid)
    ###--------------------------------------
    def pcie_read_resp(self, single=0):
        res = []
        if single == 1:
            port = []
            data = self.PCIe_ReadCtrl(0x10)
            port.append(data[0])
            res.append(port)
        else:
            for p in range(4):
                port = []
                for e in range(8):
                    data = self.PCIe_ReadCtrl(0x10 + p*8 + e)
                    port.append(data[0])
                res.append(port)
        return res
    ##----------------------------------------
    def tpgm_icfg_ecos(self, port_enab):
        self.pcie_cfig_cmnd(port_enab,  4, 0, 0, 0)
        self.pcie_issu_cmnd(LLMB_ICFG_CMND)
    def tpgm_ocfg_ecos(self, port_enab, aux0=0, aux1=0, aux2=0, aux3=0):
        self.pcie_cfig_cmnd(port_enab, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, aux0, aux1, aux2, aux3)
        self.pcie_issu_cmnd(LLMB_OCFG_CMND)
    ###--------------------------------------
    def tpem_ocfg_tpes(self, addr, data, portMsk=-1):
        if portMsk == -1:
            portMsk = 0xf00ff
        real_addr = TPES_REGS_OFFSET + addr*4
        self.pcie_cfig_cmnd(portMsk, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, real_addr, data, 0, 0)
        self.pcie_issu_cmnd(LLMB_OCFG_CMND)
    ###--------------------------------------
    def tpem_icfg_tpes(self, addr, portMsk=-1, resp=1, single=0):
        if portMsk == -1:
            portMsk = 0xf00ff
        real_addr = TPES_REGS_OFFSET + addr*4
        self.pcie_cfig_cmnd(portMsk, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, real_addr, 0, 0, 0)
        self.pcie_issu_cmnd(LLMB_ICFG_CMND)
        if resp == 1:
            res = self.pcie_read_resp(single)
        else:
            res = []
        return res
    ###--------------------------------------
    def pcie_ocfg_nnex(self, data, op):
        self.pcie_cfig_nnex(data, op)
        self.pcie_issu_cmnd(LLMB_OCFG_CMND, HardAcks=1)
    def pcie_cube_cmnd(self, LLMB_CMND, arg0=0, arg1=0, arg2=0, arg3=0, arg4=0, arg5=0, arg6=0, arg7=0, portMsk=-1, WaithAcks=0):
        self.pcie_cfig_cmnd(portMsk, 0, 0, arg0, 0, arg1, 0, 0, arg2, arg3, 0, 0, arg4, arg5, arg6, arg7)
        self.pcie_issu_cmnd(LLMB_CMND, WaithAcks)
    def pcie_ocfg_cube(self, addr, data, op=0, portMsk=-1, WaithAcks=0):
        if portMsk == -1:
            portMsk = 0xf00ff
        self.pcie_cfig_cmnd(portMsk, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, addr, data, op, 0x15000053)
        self.pcie_issu_cmnd(LLMB_OCFG_CMND, WaithAcks)
    def pcie_ocfg_cksm(self, cksum_addr, cksum_length, cksum_code, portMsk=-1):
        if portMsk == -1:
            portMsk = 0xf00ff
        self.pcie_cfig_cmnd(portMsk, 0, 0, 2, 0, cksum_addr, 0, 0, 0, 0, 0, 0, cksum_length, cksum_code, OP_CODE_CKSUM, 0x15000053)
        self.pcie_issu_cmnd(LLMB_OCFG_CMND, 0)
    def pcie_icfg_cube(self, addr, data=0, op=0, portMsk=-1, WaithAcks=0, resp=1, single=0):
        if portMsk == -1:
            portMsk = 0xf00ff
        self.pcie_cfig_cmnd(portMsk, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, addr, data, op, 0x15000054)
        self.pcie_issu_cmnd(LLMB_ICFG_CMND, WaithAcks)
        if resp == 1:
            res = self.pcie_read_resp(single)
        else:
            res = []
        return res
    def cube_ddrc_partsel(self, ddr, part):
        ddrsel = 0
        if ddr == 1:
            ddrsel = 0x00008000
        if part == 1:
            ddrsel = 0x00001000
        self.pcie_ocfg_cube(0x5008, ddrsel)
    ##====================
    def tpes_enab_rstn(self):
        self.tpem_ocfg_tpes(TPES_RSTN_CTRL, TPES_RSTN_CTRL_rstn)
    def tpes_enab_ispm(self):
        self.tpem_ocfg_tpes(TPES_SYSC_STAT, 0x00)

        self.tpem_icfg_tpes(TPES_SYSC_STAT)
        self.tpem_ocfg_tpes(TPES_SYSC_STAT, 0xff)
        self.tpem_icfg_tpes(TPES_SYSC_STAT)
        self.tpem_icfg_tpes(TPES_BAUD_RATE)
        self.tpem_icfg_tpes(TPES_UART_CTRL)

        self.ms_sleep(100)
    ##====================
    def gnpu_nnex_func(self, aux0, aux1, aux2, aux3, portMsk=-1, func=LLMB_OCFG_CMND):
        if portMsk == -1:
            portMsk = 0xf00ff
        ##  python                   1  2  3  4  5  6  7  8  9  a  b    c     d     e     f
        ##   edge                         w0    w1       w2 w3          w4    w5    w6    w7
        self.pcie_cfig_cmnd(portMsk, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, aux0, aux1, aux2, aux3)
        self.pcie_issu_cmnd(func, 0)
    def gnpu_natv_func(self, aux0, aux1, aux2, aux3, portMsk=-1, resp=0, func=LLMB_OCFG_CMND, single=0):
        if portMsk == -1:
            portMsk = 0xf00ff
        ##  python                   1  2  3  4  5  6  7  8  9  a  b    c     d     e     f
        ##   edge                         w0    w1       w2 w3          w4    w5    w6    w7
        self.pcie_cfig_cmnd(portMsk, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, aux0, aux1, aux2, aux3)
        self.pcie_issu_cmnd(func, 0)
        if resp == 1:
            res = self.pcie_read_resp(single)
        else:
            res = []
        return res
    ## 0x15000000
    def gnpu_natv_freq(self, freq, portMsk=-1):
        if portMsk == -1:
            portMsk = 0xf00ff
        print(f"gnpu_natv_freq, freq={freq}")
        self.gnpu_natv_func(freq, GNPU_ENAB_BOTH, 0, 0x15000000)
    ## 0x15000001
    def gnpu_natv_dnld(self, Code_Size, portMsk=-1):
        if portMsk == -1:
            portMsk = 0xf00ff
        print(f"gnpu_natv_dnld")
        self.gnpu_natv_func(1, GNPU_ENAB_BOTH, Code_Size, 0x15000001)
   
    ## 0x15000002
    def gnpu_natv_boot(self, Mode=RESET_RSET_BOOT, portMsk=-1):
        if portMsk == -1:
            portMsk = 0xf00ff
        print(f"gnpu_natv_boot")
        self.gnpu_natv_func(0, GNPU_ENAB_BOTH, Mode, 0x15000002)
   
    ## 0x15000003
    def gnpu_risv_freq(self, freq, ECLK=0, ICLK=3, portMsk=-1):
        if portMsk == -1:
            portMsk = 0xf00ff
        print(f"gnpu_risv_freq, freq={freq} ECLK={ECLK} ICLK={ICLK}")
        self.gnpu_natv_func(freq, ECLK, ICLK, 0x15000003)

    ## 0x15000053 1 cksum

    ## 0x15000053 2 null

    ## 0x15000053 3
    def gnpu_ocfg_scan(self, G=1):
        self.pcie_ocfg_nnex(G, op=3)

    ## 0x15000053 4
    def gnpu_ocfg_dnld(self, N=0, WaithAcks=0):
        self.pcie_ocfg_cube(0, N, op=4, WaithAcks=WaithAcks)

    ## 0x15000053 5
    def gnpu_ocfg_gemm(self, N=1250):
        self.pcie_ocfg_nnex(N, op=5)
    def gnpu_ocfg_test(self, N=1250):
        self.pcie_cfig_cmnd(0xf00ff, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, N, 5, 0x15000053)
        self.pcie_issu_cmnd(LLMB_OCFG_CMND, HardAcks=0)

    ## 0x15000053 6
    def gnpu_ocfg_stop(self, WaithAcks=0):
        self.pcie_ocfg_cube(0, 0, op=6, WaithAcks=WaithAcks)

    ## 0x15000053 7
    def gnpu_ocfg_full_scan(self, WaithAcks=0):
        self.pcie_ocfg_cube(0, 0, op=7, WaithAcks=WaithAcks)

    ## 0x15000053 8
    def gnpu_ocfg_clrs(self, addr, leng=1, WaithAcks=0):
        self.pcie_ocfg_cube(addr, leng, op=8, WaithAcks=WaithAcks)

    ## 0x15000053 9
    def gnpu_ocfg_copy(self, addr, addr2, leng, dma=0, portMsk=-1):
        if portMsk == -1:
            portMsk = 0xf00ff
        self.pcie_cube_cmnd(LLMB_OCFG_CMND,    2, addr2, dma, 0,    addr, leng, 9, 0x15000053,    portMsk=portMsk)

    ## 0x15000054 2
    def gnpu_icfg_epdc(self, addr, WaithAcks=0):
        data = self.pcie_icfg_cube(addr, 0, op=2, WaithAcks=WaithAcks)
        return data

    ## 0x15000054 7
    def gnpu_icfg_full_scan(self, WaithAcks=0):
        data = self.pcie_icfg_cube(0, 0, op=7, WaithAcks=WaithAcks)
        return data

    ## 0x15000055
    def risv_writ_conf(self, addr, data):
        self.gnpu_natv_func(addr, data, 0, 0x15000055)
   
    ## 0x15000056
    def risv_read_conf(self, addr):
        res = self.gnpu_natv_func(addr, 0, 0, 0x15000056, resp=1, func=LLMB_ICFG_CMND)
        return res
   
    ## 0x15001800
    def ocfg_writ_id(self):
        for i in range(PILE_NUM):
            for j in range(EDGE_NUM):
                edge = i * EDGE_NUM + j
                if edge >= TOTAL_GNPU//2:
                    break
                portMsk = ((2**i) << 16) | (2**j)
                self.gnpu_natv_func(2*edge, 0, 0, 0x15001800, portMsk)

    ## 0x18000000
    def gnpu_writ_id(self):
        for i in range(PILE_NUM):
            for j in range(EDGE_NUM):
                edge = i * EDGE_NUM + j
                if edge >= TOTAL_GNPU//2:
                    break
                portMsk = ((2**i) << 16) | (2**j)
                self.pcie_proc_nnex(2*edge, 0, 0, 0x18000000, portMsk)
   
    ## 0x18c00002
    def gnpu_writ_gpdr(self, vectAddr, spotAddr, data, portMsk=-1):
        if portMsk == -1:
            portMsk = 0xf00ff
        self.pcie_proc_nnex(vectAddr, spotAddr, data, 0x18c00002, portMsk)
   
    ## 0x18c10002
    def gnpu_read_gpdr(self, vectAddr, spotAddr, portMsk=-1):
    
        if portMsk == -1:
            portMsk = 0xf00ff
        self.pcie_proc_nnex(vectAddr, spotAddr, 0, 0x18c10002, portMsk)
        #res = self.gnpu_icfg_epdc(1)
        res = self.epdc_out_or_ddr(indx=1, gnpu=0, epdc=1)
        return res
   
    ## 0x18c00004
    def gnpu_writ_conf(self, addr, data, portMsk=-1):
        if portMsk == -1:
            portMsk = 0xf00ff
        self.pcie_proc_nnex(addr, 0, data, 0x18c00004, portMsk)
   
    ## 0x18c10004
    def gnpu_read_conf(self, addr, portMsk=-1):
        if portMsk == -1:
            portMsk = 0xf00ff
        self.pcie_proc_nnex(addr, 0, 0, 0x18c10004, portMsk)
        #res = self.gnpu_icfg_epdc(1)
        res = self.epdc_out_or_ddr(indx=1, gnpu=0, epdc=1)
        return res
   
    def epdc_out_or_ddr(self, indx, gnpu, epdc=0, ddrAddr=0x80002020):
        if epdc == 1:
            piles = self.pcie_icfg_cube(gnpu*0x1000 + 0x8000 + 0x34 + indx*4)
        else:
            if gnpu == 0:
                piles = self.pcie_icfg_cube(ddrAddr + indx*4)
            else:
                self.cube_ddrc_partsel(1, 0)
                piles = self.pcie_icfg_cube(ddrAddr + indx*4)
                self.cube_ddrc_partsel(0, 0)
        return piles

    ## 0x18fc0000
    def gnpu_reqs_idle(self):
        self.gnpu_nnex_func(aux0=0, aux1=0, aux2=0, aux3=0x18fc0000, portMsk=0xf00ff, func=LLMB_OCFG_CMND)
   
    def ddrAddr2cpuAddrSel(self, ddrAddr, ddr):
        if ddrAddr >= 0x80000000:
            part = 1
            cpuAddr = ddrAddr
        else:
            part = 0
            cpuAddr = ddrAddr + 0x80000000
        self.cube_ddrc_partsel(ddr, part)
        return cpuAddr

    def check_share_mem(self, m=1, n=1, pause=0):
        SHARE_MEM = LAMA_RISV_PARA[m-1]['PARA']
        cpuAddr = self.ddrAddr2cpuAddrSel(SHARE_MEM*64, ddr=0)
        i = 0
        while n > 0:
            data = self.pcie_icfg_cube(cpuAddr + i*4, single=0)
            i = i + 1
            n = n - 1
        if pause == 1:
            input(f"pause")

    ##========================================
    
    def pcie_ocfg_mgth(self, sdes):
        self.pcie_cfig_cmnd(0x0f0000,0x05,0 ,0 ,0,0,0,0,0,0,0,0 , sdes, 0, 0, 0)
        self.pcie_issu_cmnd(LLMB_OCFG_CMND)
    
    def pcie_icfg_mgth (self, want):
        self.pcie_cfig_cmnd(0x0f0000,0x05,0 ,0 ,0,0,0,0,0,0,0,0 , 0, 0, 0, 0)
        while 1:
            self.us_sleep(100)
            self.pcie_issu_cmnd(LLMB_ICFG_CMND)
            rgs0 = self.PCIe_ReadCtrl(TPGS0_ACKS_DATA0, 1)
            rgs1 = self.PCIe_ReadCtrl(TPGS1_ACKS_DATA0, 1)
            rgs2 = self.PCIe_ReadCtrl(TPGS2_ACKS_DATA0, 1)
            rgs3 = self.PCIe_ReadCtrl(TPGS3_ACKS_DATA0, 1)
            print(".",end="")
            if rgs0[0] == 0x3f0000 and rgs1[0] == 0x2b0000 and rgs2[0] == 0x2b0000 and rgs3[0] == 0x2b0000:
                print(f"\nROOT MGTH_SERDES Link  Successfully!!!")
                break
        
    ##========================================
    
    def root_link_hubs_sdes(self):
        self.pcie_ocfg_mgth(0x15)
        self.ms_sleep(100)
        self.pcie_ocfg_mgth(0)
        self.ms_sleep(100)
        self.pcie_icfg_mgth(0xc)
 
    def tpgm_rism_tpgs(self, master_addr, meta_rows, meta_cols_page, hubs_cols_page, hubs_dummy_page=0):
        for P in [1,2,3]:
            portMsk = ((2**P) << 16) | 0x00010000
            hubs_bias_page = hubs_cols_page * P
            self.pcie_cfig_cmnd(portMsk, 5, 0, 0,  master_addr, hubs_bias_page, meta_rows, meta_cols_page, hubs_cols_page, hubs_dummy_page, P, 0,0,0,0,0)
            self.pcie_issu_cmnd(LLMB_RISM_CMND)
        
       
    def tpgm_rsim_tpgs_uniq(self, IMAGE_ROWS, ROOT_ADDR, HUBS_BIAS, ROOT_COLS, HUBS_COLS=0X80, HUBS_DUMY=0X0, P=0):
        portMsk = ((2**P) << 16) | 0x00010000
        self.pcie_cfig_cmnd(portMsk, 5, 0, 0,  ROOT_ADDR, HUBS_BIAS, IMAGE_ROWS, ROOT_COLS, HUBS_COLS, HUBS_DUMY, P, 0,0,0,0,0)
        self.pcie_issu_cmnd(LLMB_RISM_CMND)
        #print("s")

    def tpgm_rism_tpgs_2560_64x40(self, rows, master_addr):
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=0xA0,     HUBS_BIAS=0X40,  HUBS_COLS=64, HUBS_DUMY=0, P=1)
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=0xA0,     HUBS_BIAS=0X80,  HUBS_COLS=32, HUBS_DUMY=32, P=2)

    def tpgm_rism_tpgs_5120_128x40(self, rows, master_addr):        
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=320,    HUBS_BIAS=128,     HUBS_COLS=128, HUBS_DUMY= 0, P=1)
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=320,    HUBS_BIAS=256,     HUBS_COLS= 64, HUBS_DUMY=64, P=2)

    def tpgm_rism_tpgs_5120_96x64(self, rows, master_addr):     
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=320,    HUBS_BIAS= 96,     HUBS_COLS=96, HUBS_DUMY= 0, P=1)
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=320,    HUBS_BIAS=192,     HUBS_COLS=96, HUBS_DUMY= 0, P=2)
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=320,    HUBS_BIAS=288,     HUBS_COLS=32, HUBS_DUMY=64, P=3)

    def tpgm_rism_tpgs_27648_448x64(self, rows, master_addr):       
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=1728,   HUBS_BIAS=448,     HUBS_COLS=448, HUBS_DUMY= 0, P=1)
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=1728,   HUBS_BIAS=896,     HUBS_COLS=448, HUBS_DUMY= 0, P=2)
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=1728,   HUBS_BIAS=1344,    HUBS_COLS=384, HUBS_DUMY=64, P=3)

    def tpgm_rism_tpgs_152064_2400x64(self, rows, master_addr):       
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=9504,   HUBS_BIAS=4800,    HUBS_COLS=2400, HUBS_DUMY= 0, P=2)
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=9504,   HUBS_BIAS=2400,    HUBS_COLS=2400, HUBS_DUMY= 0, P=1)
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=9504,   HUBS_BIAS=7200,    HUBS_COLS=2400, HUBS_DUMY=96, P=3)

    def tpgm_rism_tpgs_attn(self, rows, master_addr):
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=0X140,  HUBS_BIAS=0X100,   HUBS_COLS=0X40, HUBS_DUMY=0X40, P=2)
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=0X140,  HUBS_BIAS=0X80 ,   HUBS_COLS=0X80, HUBS_DUMY=0X0 , P=1)

    def tpgm_rism_tpgs_hint(self, rows, master_addr):       
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=0X140,  HUBS_BIAS=0XC0 ,   HUBS_COLS=0X60, HUBS_DUMY=0X0 , P=2)
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=0X140,  HUBS_BIAS=0X60 ,   HUBS_COLS=0X60, HUBS_DUMY=0X0 , P=1)
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=0X140,  HUBS_BIAS=0X120,   HUBS_COLS=0X20, HUBS_DUMY=0X40, P=3)

    def tpgm_rism_tpgs_ugat(self, rows, master_addr):       
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=0X6C0,  HUBS_BIAS=0X1C0,   HUBS_COLS=0X1C0, HUBS_DUMY=0X0 , P=1)
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=0X6C0,  HUBS_BIAS=0X380,   HUBS_COLS=0X1C0, HUBS_DUMY=0X0 , P=2)
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=0X6C0,  HUBS_BIAS=0X540,   HUBS_COLS=0X180, HUBS_DUMY=0X40, P=3)

    def tpgm_rism_tpgs_down(self, rows, master_addr):       
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=0X140,  HUBS_BIAS=0XC0 ,   HUBS_COLS=0X60, HUBS_DUMY=0X0 , P=2)
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=0X140,  HUBS_BIAS=0X60 ,   HUBS_COLS=0X60, HUBS_DUMY=0X0 , P=1)
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=0X140,  HUBS_BIAS=0X120,   HUBS_COLS=0X20, HUBS_DUMY=0X40, P=3)

    def tpgm_rism_tpgs_vcbr(self, rows, master_addr):
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=3200, HUBS_BIAS=1600,  HUBS_COLS=800, HUBS_DUMY=0X0 , P=2)
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=3200, HUBS_BIAS=800 ,  HUBS_COLS=800, HUBS_DUMY=0X0 , P=1)
        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=3200, HUBS_BIAS=2400,  HUBS_COLS=800, HUBS_DUMY=0X0, P=3)
#        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=0X2520, HUBS_BIAS=0X12C0,  HUBS_COLS=0X960, HUBS_DUMY=0X0 , P=2)
#        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=0X2520, HUBS_BIAS=0X960 ,  HUBS_COLS=0X960, HUBS_DUMY=0X0 , P=1)
#        self.tpgm_rsim_tpgs_uniq(IMAGE_ROWS=rows, ROOT_ADDR=master_addr, ROOT_COLS=0X2520, HUBS_BIAS=0X1C20,  HUBS_COLS=0X900, HUBS_DUMY=0X60, P=3)

    def tpgm_rimt_init(self):
        self.tpgm_rimt_tpes(0x01000000, 0x1000, 1, 16*128, 1, 128,  READ_NNEX_DATA_NULL, GSME, 0xf00ff)
        self.tpgm_rimt_tpes(0x01000000, 0x1000, 1, 16*128, 1, 128,  READ_NNEX_DATA_NULL, GSMO, 0xf00ff)


    def tpgm_rimt_tpes(self, slave_addr, master_addr, meta_cols, port_rows, port_cols, edge_rows, edge_cols, OP, gsml, portMsk=-1):
        if portMsk == -1:
            portMsk = 0xf00ff
        if edge_cols > 2016:
            self.tpgm_rimt_tpes_2rows(slave_addr, master_addr, meta_cols,port_rows, port_cols, edge_rows, edge_cols, OP, gsml, portMsk)
        else:
            self.tpgm_rimt_tpes_1rows(slave_addr, master_addr, meta_cols,port_rows, port_cols, edge_rows, edge_cols, OP, gsml, portMsk)
        

    def tpgm_rimt_tpes_1rows(self, slave_addr, master_addr, meta_cols,port_rows, port_cols, edge_rows, edge_cols, OP, gsml, portMsk=-1):
        if portMsk == -1:
            portMsk = 0xf00ff
        self.pcie_cfig_cmnd(portMsk, 0, 0, gsml, master_addr, slave_addr, port_rows, port_cols, edge_rows, edge_cols, 0, meta_cols, 0, 0, 0, OP)
        self.pcie_issu_cmnd(LLMB_RIMT_CMND)
        #print("1")
        

    def tpgm_rimt_tpes_2rows(self, slave_addr, master_addr, meta_cols,port_rows, port_cols, edge_rows, edge_cols, OP, gsml, portMsk=-1):
        if portMsk == -1:
            portMsk = 0xf00ff
        self.pcie_cfig_cmnd(portMsk, 0, 0, gsml, master_addr, slave_addr, port_rows, port_cols, edge_rows*2, edge_cols//2, 1, meta_cols, 0, 0, 0, OP)
        self.pcie_issu_cmnd(LLMB_RIMT_CMND)
        #print("2")
        

    def tpgm_ivct_tpes(self, slave_addr, master_addr, meta_rows, meta_cols, edge_rows, edge_cols, OP, gsml, portMsk=-1):
        if edge_cols > 2016:
           sys.exit(0)

        if portMsk == -1:
            portMsk = 0xf00ff
        self.pcie_cfig_cmnd(portMsk, 0, 0, gsml, master_addr, slave_addr, meta_rows, meta_cols, edge_rows, edge_cols, 0, 0, 0, 0, 0, OP)
        #input(f"LLMB_IVCT_CMND:")
        self.pcie_issu_cmnd(LLMB_IVCT_CMND)

    def tpgm_ovct_tpes(self, slave_addr, master_addr, meta_rows, meta_cols, edge_rows, edge_cols, OP, dvpx, portMsk=-1):
        if portMsk == -1:
            portMsk = 0xf00ff
        self.pcie_cfig_cmnd(portMsk, 0, 0, dvpx, master_addr, slave_addr, meta_rows, meta_cols, edge_rows, edge_cols, 0, 0, 0, 0, 0, OP)
        #input(f"LLMB_OVCT_CMND:")
        #self.ms_sleep(1000)
        #self.ms_sleep(500)
        #self.ms_sleep(200)
        self.pcie_issu_cmnd(LLMB_OVCT_CMND)


    def tpgm_omtx_tpes(self, slave_addr, master_addr, meta_rows, meta_cols, OP, dvpx, portMsk=-1):
        if portMsk == -1:
            portMsk = 0xf00ff
        rows_md32 = meta_rows // 32
        rows_tile = rows_md32 * 32
        rows_left = meta_rows - rows_tile
        CustomRow = int(rows_tile * meta_cols / CustomCol)
        if rows_tile > 0:
            self.tpgm_omtx_tile(slave_addr, master_addr, rows_tile, meta_cols, CustomRow, CustomCol, OP, dvpx, portMsk)
        if rows_left > 0:
            mast_offset = rows_tile * meta_cols // 16
            slav_offset = mast_offset // 2
            master_addr = master_addr + mast_offset
            slave_addr = slave_addr + slav_offset
            left_cols = rows_left * 128
            left_rows = rows_left * meta_cols // left_cols
            self.tpgm_omtx_tile(slave_addr, master_addr, rows_left, meta_cols, left_rows, left_cols, OP, dvpx, portMsk)

    def tpgm_omtx_tile(self, slave_addr, master_addr, meta_rows, meta_cols, edge_rows, edge_cols, OP, dvpx, portMsk=-1):
        if portMsk == -1:
            portMsk = 0xf00ff
        self.pcie_cfig_cmnd(portMsk, 0, 0, dvpx, master_addr, slave_addr, meta_rows, meta_cols, edge_rows, edge_cols, 0, 0, 0, 0, 0, OP)
        self.pcie_issu_cmnd(LLMB_OMTX_CMND)

    ##----------------------------------------
    
    def tpgm_ivct_tpgs(self, slave_addr, master_addr, meta_rows, meta_cols, portMsk=-1):
        if portMsk == -1:
            portMsk = 0xf00ff
        self.pcie_cfig_cmnd(portMsk, 3, 0, 0, master_addr, slave_addr, meta_rows, meta_cols, meta_rows, meta_cols, 0, 0, 0, 0, 0, 0)
        self.pcie_issu_cmnd(LLMB_IVCT_CMND)

    def tpgm_ovct_tpgs(self, slave_addr, master_addr, meta_rows, meta_cols, portMsk=-1):
        if portMsk == -1:
            portMsk = 0xf00ff
        self.pcie_cfig_cmnd(portMsk, 3, 0, 0, master_addr, slave_addr, meta_rows, meta_cols, meta_rows, meta_cols, 0, 0, 0, 0, 0, 0)
        self.pcie_issu_cmnd(LLMB_OVCT_CMND)
    
    def pcie_timer(self, dT, job):
        delta = datetime.timedelta(dT/(24*60*60))
        t0 = self.Time
        t1 = datetime.datetime.now()
        if dT == 0 or (t1 - t0) > delta:
            job()
            self.Time = t1
##############################################################################################3
    def root_ivct_hubs_ddrs(self,  master_addr, slave_addr,meta_rows, meta_cols, hubs=-1):
        if(hubs < 1 and hubs > 3):
            print(f"ROOT_IVCT_HUBS PORT_ENABLE Invalid@{hubs}")
            return
        portEn = 0x20000 << (hubs - 1)
        #portEn = 0x10000 | ((2**hubs)<<16) 
        self.pcie_cfig_cmnd(portEn, 3, 0, 0, master_addr, slave_addr, meta_rows, meta_cols, meta_rows, meta_cols, 0, 0, 0, 0, 0, 0)
        self.pcie_issu_cmnd(LLMB_IVCT_CMND)
##############################################################################################3
    def root_ovct_hubs_ddrs(self,  master_addr, slave_addr,meta_rows, meta_cols, hubs=-1):
        if(hubs < 1 and hubs > 3):
            print(f"ROOT_OVCT_HUBS PORT_ENABLE Invalid@{hubs}")
            return
        #portEn = 0x20000 << (portMsk - 1)
        portEn = 0x20000 << (hubs - 1)
        self.pcie_cfig_cmnd(portEn, 3, 0, 0, master_addr, slave_addr, meta_rows, meta_cols, meta_rows, meta_cols, 0, 0, 0, 0, 0, 0)
        self.pcie_issu_cmnd(LLMB_OVCT_CMND)
##############################################################################################3
    def root_rsim_hubs_ddrs(self, root_rows, root_addr, root_cols, hubs_bias,  hubs_cols=0X80, hubs_dmmy=0X0, p=0):
        if((p==0) or(p>3)):
            print("Illegal Port::{P:08x} setting,Fetal Error!")
            return
        portMsk = ((2**p) << 16) | 0x00010000
        self.pcie_cfig_cmnd(portMsk, 5, 0, 0,  root_addr, hubs_bias, root_rows, root_cols, hubs_cols, hubs_dmmy, p, 0,0,0,0,0)
        self.pcie_issu_cmnd(LLMB_RISM_CMND)
##############################################################################################
    def root_ovct_gnpu_ddrs(self, hubs, edge , gnpu, madd, sadd, rows, cols):
        if(hubs==0xf and edge == 0xff):
            portMsk = 0xf00ff
        else :
            portMsk = ((2**hubs)<<16) | (2**edge)    
        self.pcie_cfig_cmnd(portMsk, 0, 0, gnpu+3, madd, sadd, rows, cols, rows, cols, 0, 0, 0, 0, 0, 0X100000F0)
        self.pcie_issu_cmnd(LLMB_OVCT_CMND)
##############################################################################################
    def root_ovct_gnpu_code(self, hubs, edge , gnpu, madd, sadd, rows, cols):
        if(hubs==0xf and edge == 0xff):
            portMsk = 0xf00ff
        else :
            portMsk = ((2**hubs)<<16) | (2**edge)    
        self.pcie_cfig_cmnd(portMsk, 0, 0, gnpu+3, madd, sadd, rows, cols, rows, cols, 0, 0, 0, 0, 0, 0X10000080)
        self.pcie_issu_cmnd(LLMB_OVCT_CMND)
##############################################################################################
    def root_ovct_gnpu_wght(self,portMsk, gnpu, madd, sadd, rows, cols):
        self.pcie_cfig_cmnd(portMsk, 0, 0, gnpu, madd, sadd, rows, cols, rows, cols, 0, 0, 0, 0, 0, 0X100000F0)
        self.pcie_issu_cmnd(LLMB_OVCT_CMND)
##############################################################################################
    def root_omtx_gnpu_rect(self, hubs, edge , gnpu, madd, sadd, rows, cols):
        if(hubs==0xf and edge == 0xff):
            portMsk = 0xf00ff
        else :
            portMsk = ((2**hubs)<<16) | (2**edge)

        rect_size =     rows*cols
        rect_cols =     rows*128
        rect_rows =int(rect_size/rect_cols)
        
#        print(f"----OMTX_RECT [ RAWS_ROW::{rows} RAWS_COL::{cols} ] => [ RECT_ROW::{rect_rows} TILE_COL::{rect_cols} ]")

        self.pcie_cfig_cmnd(portMsk, 0, 0, gnpu+3, madd, sadd, rows, cols, rect_rows, rect_cols, 0, 0, 0, 0, 0, 0X100000F0)
        self.pcie_issu_cmnd(LLMB_OMTX_CMND)
##############################################################################################
    def root_omtx_gnpu_tile(self, hubs, edge , gnpu, madd, sadd, rows, cols):
        if(hubs==0xf and edge == 0xff):
            portMsk = 0xf00ff
        else :
            portMsk = ((2**hubs)<<16) | (2**edge)

        tile_size =     rows*cols
        tile_rows = int(tile_size/ 4096)

#        print(f"----OMTX_TILE [ RAWS_ROW::{rows} RAWS_COL::{cols} ] => [ TILE_ROW::{tile_rows} TILE_COL::4096 ]")

        self.pcie_cfig_cmnd(portMsk, 0, 0, gnpu+3, madd, sadd, rows, cols, tile_rows, 4096, 0, 0, 0, 0, 0, 0X100000F0)
        self.pcie_issu_cmnd(LLMB_OMTX_CMND)
        return 1
##############################################################################################
    def root_omtx_gnpu_ddrs(self, hubs, edge , gnpu, madd, sadd, rows, cols):
        
        tile_rows   =  rows&0xffffffe0 
        rect_rows   =  rows&0x0000001f

        mast_skip_ofst = 0  
        slav_skip_ofst = 0  
        
        while(tile_rows !=0 ):
            self.root_omtx_gnpu_tile(hubs, edge , gnpu, madd+mast_skip_ofst, sadd+slav_skip_ofst, tile_rows, cols)
            tile_rows = tile_rows -32
            mast_skip_ofst =  cols << 1 #*32 /16 
            slav_skip_ofst =  cols      #*32 /32   
           
        
        if rect_rows != 0   :
            self.root_omtx_gnpu_rect(hubs, edge , gnpu, madd+mast_skip_ofst, sadd+slav_skip_ofst, rect_rows, cols)
##############################################################################################
    def root_ivct_gnpu_ddrs(self, hubs, edge , gnpu, madd, sadd, rows, cols):
        if cols > 2016:
            print(f"CMND_IVCT_COLS({cols}) > 2016 ,Exceed Maximum Column Dimense,Exit ")
            sys.exit(0)

        portMsk = ((2**hubs)<<16) | (2**edge)
        ivct_rows   =   rows
        while ivct_rows > 0 :
            if(ivct_rows < 2048):
                self.pcie_cfig_cmnd(portMsk, 0, 0, gnpu+6, madd, sadd, ivct_rows, cols, rows, cols, 0, 0, 0, 0, 0, 0X110000F0)
                self.pcie_issu_cmnd(LLMB_IVCT_CMND)                    
                ivct_rows = 0
            else :
                self.pcie_cfig_cmnd(portMsk, 0, 0, gnpu+6, madd, sadd, 2048, cols, rows, cols, 0, 0, 0, 0, 0, 0X110000F0)
                self.pcie_issu_cmnd(LLMB_IVCT_CMND)                    
                ivct_rows -=  2048  
                madd += 2048 * cols // 16
                sadd += 2048 * cols // 32
                
##############################################################################################
    def root_rimt_gnpu_ddrs(self, gnpu, madd, sadd, rows, cols, dims):
        self.pcie_cfig_cmnd(0xf00ff, 0, 0, gnpu+6, madd, sadd, rows, cols*16, rows, cols, 0, dims, 0, 0, 0, 0X110000F0)
        self.pcie_issu_cmnd(LLMB_RIMT_CMND)                    
##############################################################################################
    def root_nnex_gnpu_task(self, posi, leng, LOOP, OP):
        self.pcie_cfig_cmnd(0xf00ff, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, posi, leng, LOOP, OP)
        self.pcie_issu_cmnd(LLMB_NNEX_CMND)
